<div class="mg-contacts-block">
    <div class="phone">
        <div class="phone-item">
            <?php echo MG::getSetting('shopPhone') ?>
        </div>
    </div>
</div>
