DROP TABLE IF EXISTS `mg_avito_cats`, `mg_avito_locations`, `mg_avito_settings`, `mg_brand-logo`, `mg_cache`, `mg_category`, `mg_category_user_property`, `mg_comments`, `mg_custom_order_fields`, `mg_delivery`, `mg_delivery_payment_compare`, `mg_googlemerchant`, `mg_googlemerchantcats`, `mg_landings`, `mg_locales`, `mg_messages`, `mg_notification`, `mg_order`, `mg_page`, `mg_payment`, `mg_plugins`, `mg_product`, `mg_product_on_storage`, `mg_product_rating`, `mg_product_user_property`, `mg_product_user_property_data`, `mg_product_variant`, `mg_property`, `mg_property_data`, `mg_property_group`, `mg_sessions`, `mg_setting`, `mg_site-block-editor`, `mg_slider-action`, `mg_trigger-guarantee`, `mg_trigger-guarantee-elements`, `mg_url_redirect`, `mg_url_rewrite`, `mg_user`, `mg_user_group`, `mg_vk-export`, `mg_wholesales_sys`, `mg_yandexmarket`;

CREATE TABLE `mg_avito_cats` (
  `id` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `parent_id` int(255) NOT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE `mg_avito_locations` (
  `id` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `type` int(5) NOT NULL,
  `parent_id` int(255) NOT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE `mg_avito_settings` (
  `name` varchar(255) NOT NULL,
  `settings` longtext NOT NULL,
  `cats` longtext NOT NULL,
  `additional` longtext NOT NULL,
  `edited` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE `mg_brand-logo` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Порядковый номер записи',
  `brand` text NOT NULL COMMENT 'Бренд',
  `url` text NOT NULL COMMENT 'Логотип',
  `desc` text NOT NULL COMMENT 'Описание',
  `sort` int(11) NOT NULL COMMENT 'Порядок',
  `seo_title` text NOT NULL,
  `seo_keywords` text NOT NULL,
  `seo_desc` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

CREATE TABLE `mg_cache` (
  `date_add` int(11) NOT NULL,
  `lifetime` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `value` longtext NOT NULL,
  UNIQUE KEY `name` (`name`),
  KEY `name_2` (`name`),
  KEY `date_add` (`date_add`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE `mg_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `left_key` int(11) NOT NULL DEFAULT '1',
  `right_key` int(11) NOT NULL DEFAULT '1',
  `level` int(11) NOT NULL DEFAULT '2',
  `title` varchar(255) DEFAULT NULL,
  `menu_title` varchar(255) NOT NULL DEFAULT '',
  `url` varchar(255) DEFAULT NULL,
  `parent` int(11) NOT NULL,
  `parent_url` varchar(255) NOT NULL,
  `sort` int(11) DEFAULT NULL,
  `html_content` longtext,
  `meta_title` varchar(255) DEFAULT NULL,
  `meta_keywords` varchar(512) DEFAULT NULL,
  `meta_desc` text,
  `invisible` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'Не выводить в меню',
  `1c_id` varchar(255) DEFAULT NULL,
  `image_url` text,
  `menu_icon` text,
  `rate` double NOT NULL DEFAULT '0',
  `export` tinyint(1) NOT NULL DEFAULT '1',
  `seo_content` text,
  `activity` tinyint(1) NOT NULL DEFAULT '1',
  `unit` varchar(255) NOT NULL DEFAULT 'шт.',
  `seo_alt` text,
  `seo_title` text,
  `countProduct` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `1c_id` (`1c_id`),
  KEY `url` (`url`),
  KEY `parent_url` (`parent_url`),
  KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=26 DEFAULT CHARSET=utf8;

CREATE TABLE `mg_category_user_property` (
  `category_id` int(11) NOT NULL,
  `property_id` int(11) NOT NULL,
  KEY `category_id` (`category_id`),
  KEY `property_id` (`property_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE `mg_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `email` varchar(45) NOT NULL,
  `comment` text NOT NULL,
  `date` timestamp NOT NULL,
  `uri` varchar(255) NOT NULL,
  `approved` tinyint(4) NOT NULL DEFAULT '0',
  `img` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE `mg_custom_order_fields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `field` text NOT NULL,
  `id_order` int(11) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE `mg_delivery` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `cost` double DEFAULT NULL,
  `description` text,
  `activity` int(1) NOT NULL DEFAULT '0',
  `free` double DEFAULT NULL COMMENT 'Бесплатно от',
  `date` int(1) DEFAULT NULL,
  `sort` int(11) DEFAULT NULL,
  `ymarket` int(1) DEFAULT NULL,
  `plugin` varchar(255) DEFAULT NULL,
  `weight` longtext,
  `interval` longtext,
  `address_parts` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='таблица способов доставки товара';

CREATE TABLE `mg_delivery_payment_compare` (
  `payment_id` int(10) DEFAULT NULL,
  `delivery_id` int(10) DEFAULT NULL,
  `compare` int(1) DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE `mg_googlemerchant` (
  `name` varchar(255) NOT NULL,
  `settings` longtext NOT NULL,
  `cats` longtext NOT NULL,
  `edited` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE `mg_googlemerchantcats` (
  `id` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `parent_id` int(255) NOT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE `mg_landings` (
  `id` int(11) NOT NULL,
  `template` varchar(255) DEFAULT NULL,
  `templateColor` varchar(6) DEFAULT NULL,
  `ytp` longtext,
  `image` varchar(255) DEFAULT NULL,
  `buySwitch` varchar(6) DEFAULT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE `mg_locales` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_ent` int(11) NOT NULL,
  `locale` varchar(255) NOT NULL,
  `table` varchar(255) NOT NULL,
  `field` varchar(255) NOT NULL,
  `text` longtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `id_ent` (`id_ent`),
  KEY `locale` (`locale`),
  KEY `table` (`table`),
  KEY `field` (`field`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE `mg_messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `text` text NOT NULL,
  `text_original` text NOT NULL,
  `group` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=54 DEFAULT CHARSET=utf8;

CREATE TABLE `mg_notification` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `message` longtext NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE `mg_order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `updata_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `add_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `close_date` timestamp NULL DEFAULT NULL,
  `pay_date` timestamp NULL DEFAULT NULL,
  `user_email` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `address` text,
  `address_parts` text,
  `summ` varchar(255) DEFAULT NULL COMMENT 'Общая сумма товаров в заказе ',
  `order_content` longtext,
  `delivery_id` int(11) unsigned DEFAULT NULL,
  `delivery_cost` double DEFAULT NULL COMMENT 'Стоимость доставки',
  `delivery_interval` text,
  `delivery_options` text,
  `payment_id` int(11) DEFAULT NULL,
  `paided` int(1) NOT NULL DEFAULT '0',
  `status_id` int(11) DEFAULT NULL,
  `user_comment` text,
  `comment` text,
  `confirmation` varchar(255) DEFAULT NULL,
  `yur_info` text NOT NULL,
  `name_buyer` text NOT NULL,
  `date_delivery` text,
  `ip` text NOT NULL,
  `number` varchar(32) DEFAULT NULL,
  `hash` varchar(32) DEFAULT NULL,
  `1c_last_export` timestamp NULL DEFAULT NULL,
  `orders_set` int(11) DEFAULT NULL,
  `storage` text NOT NULL,
  `summ_shop_curr` double DEFAULT NULL,
  `delivery_shop_curr` double DEFAULT NULL,
  `currency_iso` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `user_email` (`user_email`),
  KEY `status_id` (`status_id`),
  KEY `1c_last_export` (`1c_last_export`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE `mg_page` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_url` varchar(255) NOT NULL,
  `parent` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `html_content` longtext,
  `meta_title` varchar(255) DEFAULT NULL,
  `meta_keywords` varchar(1024) DEFAULT NULL,
  `meta_desc` text,
  `sort` int(11) DEFAULT NULL,
  `print_in_menu` tinyint(4) NOT NULL DEFAULT '0',
  `invisible` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'Не выводить в меню',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

CREATE TABLE `mg_payment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(1024) NOT NULL,
  `activity` int(1) NOT NULL DEFAULT '0',
  `paramArray` text,
  `urlArray` varchar(1024) DEFAULT NULL,
  `rate` double NOT NULL DEFAULT '0',
  `sort` int(11) DEFAULT NULL,
  `add_security` varchar(255) NOT NULL,
  `permission` varchar(5) NOT NULL DEFAULT 'fiz',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

CREATE TABLE `mg_plugins` (
  `folderName` varchar(255) NOT NULL,
  `active` tinyint(1) NOT NULL,
  UNIQUE KEY `name` (`folderName`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE `mg_product` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sort` int(11) DEFAULT NULL,
  `cat_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` longtext,
  `price` double NOT NULL,
  `url` varchar(255) NOT NULL,
  `image_url` text,
  `code` varchar(255) NOT NULL,
  `count` int(11) NOT NULL DEFAULT '0',
  `activity` tinyint(1) NOT NULL,
  `meta_title` varchar(255) DEFAULT NULL,
  `meta_keywords` varchar(1024) DEFAULT NULL,
  `meta_desc` text,
  `old_price` varchar(255) DEFAULT NULL,
  `recommend` tinyint(4) NOT NULL DEFAULT '0',
  `new` tinyint(4) NOT NULL DEFAULT '0',
  `related` text,
  `inside_cat` text,
  `1c_id` varchar(255) NOT NULL DEFAULT '',
  `weight` double DEFAULT NULL,
  `link_electro` varchar(1024) DEFAULT NULL,
  `currency_iso` varchar(255) DEFAULT NULL,
  `price_course` double DEFAULT NULL,
  `image_title` text,
  `image_alt` text,
  `yml_sales_notes` text,
  `count_buy` int(11) DEFAULT NULL,
  `system_set` int(11) DEFAULT NULL,
  `related_cat` text,
  `short_description` longtext,
  `last_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `unit` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `1c_id` (`1c_id`),
  KEY `id` (`id`),
  KEY `cat_id` (`cat_id`),
  KEY `url` (`url`),
  KEY `code` (`code`),
  FULLTEXT KEY `SEARCHPROD` (`title`,`description`,`code`,`meta_title`,`meta_keywords`,`meta_desc`)
) ENGINE=MyISAM AUTO_INCREMENT=71 DEFAULT CHARSET=utf8;

CREATE TABLE `mg_product_on_storage` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `storage` varchar(255) NOT NULL,
  `product_id` int(11) NOT NULL,
  `variant_id` int(11) NOT NULL,
  `count` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`),
  KEY `variant_id` (`variant_id`),
  KEY `storage` (`storage`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE `mg_product_rating` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Порядковый номер записи',
  `id_product` int(11) NOT NULL COMMENT 'ID товара',
  `rating` double NOT NULL COMMENT 'Оценка',
  `count` int(11) NOT NULL COMMENT 'Количество голосов',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=29 DEFAULT CHARSET=utf8;

CREATE TABLE `mg_product_user_property` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `property_id` int(11) NOT NULL,
  `value` text NOT NULL,
  `product_margin` text NOT NULL COMMENT 'наценка продукта',
  `type_view` enum('checkbox','select','radiobutton','') NOT NULL DEFAULT 'select',
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`),
  KEY `property_id` (`property_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Таблица пользовательских свойств продуктов';

CREATE TABLE `mg_product_user_property_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `prop_id` int(11) NOT NULL,
  `prop_data_id` int(11) NOT NULL DEFAULT '0',
  `product_id` int(11) NOT NULL,
  `name` text,
  `margin` text,
  `type_view` text NOT NULL,
  `active` tinyint(4) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `prop_id` (`prop_id`),
  KEY `product_id` (`product_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE `mg_product_variant` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `title_variant` varchar(255) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `sort` int(11) DEFAULT NULL,
  `price` double NOT NULL,
  `old_price` varchar(255) NOT NULL,
  `count` int(11) DEFAULT NULL,
  `code` varchar(255) DEFAULT NULL,
  `activity` tinyint(1) NOT NULL,
  `weight` double NOT NULL,
  `currency_iso` varchar(255) DEFAULT NULL,
  `price_course` double DEFAULT NULL,
  `1c_id` varchar(255) DEFAULT NULL,
  `color` varchar(255) NOT NULL,
  `size` varchar(255) NOT NULL,
  `last_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`),
  FULLTEXT KEY `title_variant` (`title_variant`),
  FULLTEXT KEY `code` (`code`)
) ENGINE=MyISAM AUTO_INCREMENT=359 DEFAULT CHARSET=utf8;

CREATE TABLE `mg_property` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `default` text,
  `data` text,
  `all_category` tinyint(1) DEFAULT NULL,
  `activity` int(1) NOT NULL DEFAULT '0',
  `sort` int(11) DEFAULT NULL,
  `filter` tinyint(1) NOT NULL DEFAULT '0',
  `description` text,
  `type_filter` varchar(32) DEFAULT NULL,
  `1c_id` varchar(255) DEFAULT NULL,
  `plugin` varchar(255) DEFAULT NULL,
  `unit` varchar(32) DEFAULT NULL,
  `group_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `name` (`name`),
  KEY `1c_id` (`1c_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE `mg_property_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `prop_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `margin` text NOT NULL,
  `sort` int(11) NOT NULL DEFAULT '1',
  `color` varchar(45) NOT NULL,
  `img` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `name` (`name`),
  KEY `prop_id` (`prop_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE `mg_property_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `sort` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE `mg_sessions` (
  `session_id` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  `session_expires` int(11) unsigned NOT NULL DEFAULT '0',
  `session_data` longtext,
  PRIMARY KEY (`session_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `mg_setting` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `option` varchar(255) NOT NULL,
  `value` longtext,
  `active` varchar(1) NOT NULL DEFAULT 'N',
  `name` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `option` (`option`),
  KEY `option_2` (`option`)
) ENGINE=MyISAM AUTO_INCREMENT=182 DEFAULT CHARSET=utf8;

CREATE TABLE `mg_site-block-editor` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `comment` text NOT NULL,
  `type` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `width` text NOT NULL,
  `height` text NOT NULL,
  `alt` text NOT NULL,
  `title` text NOT NULL,
  `href` text NOT NULL,
  `class` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE `mg_slider-action` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Порядковый номер записи',
  `type` varchar(255) NOT NULL COMMENT 'Тип слайда картинка или HTML',
  `nameaction` text NOT NULL COMMENT 'Название слайда',
  `href` text NOT NULL COMMENT 'ссылка',
  `value` text NOT NULL COMMENT 'значение',
  `sort` int(11) NOT NULL COMMENT 'Порядок слайдов',
  `invisible` int(1) NOT NULL COMMENT 'видимость',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

CREATE TABLE `mg_trigger-guarantee` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Порядковый номер',
  `title` text NOT NULL COMMENT 'Загаловок',
  `settings` text NOT NULL COMMENT 'Настройки',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE `mg_trigger-guarantee-elements` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Порядковый номер',
  `parent` int(11) NOT NULL COMMENT 'id блока',
  `text` text NOT NULL COMMENT 'Текст триггера',
  `icon` text NOT NULL COMMENT 'Иконка или url картинки',
  `sort` int(11) NOT NULL COMMENT 'Сортировка',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE `mg_url_redirect` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `url_old` text NOT NULL,
  `url_new` text NOT NULL,
  `code` int(3) NOT NULL,
  `activity` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE `mg_url_rewrite` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `url` text NOT NULL,
  `short_url` varchar(255) NOT NULL,
  `titeCategory` varchar(255) DEFAULT NULL,
  `cat_desc` longtext NOT NULL,
  `meta_title` varchar(255) NOT NULL,
  `meta_keywords` varchar(1024) NOT NULL,
  `meta_desc` text NOT NULL,
  `activity` tinyint(1) NOT NULL DEFAULT '1',
  `cat_desc_seo` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE `mg_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) DEFAULT NULL,
  `pass` varchar(255) DEFAULT NULL,
  `role` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `sname` varchar(255) DEFAULT NULL,
  `address` text,
  `address_index` text,
  `address_country` text,
  `address_region` text,
  `address_city` text,
  `address_street` text,
  `address_house` text,
  `address_flat` text,
  `phone` varchar(255) DEFAULT NULL,
  `last_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `date_add` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `blocked` int(1) NOT NULL DEFAULT '0',
  `restore` varchar(255) DEFAULT NULL,
  `activity` int(1) DEFAULT '0',
  `inn` text,
  `kpp` text,
  `nameyur` text,
  `adress` text,
  `bank` text,
  `bik` text,
  `ks` text,
  `rs` text,
  `birthday` text,
  `ip` text,
  PRIMARY KEY (`id`),
  KEY `email` (`email`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

CREATE TABLE `mg_user_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `can_drop` tinyint(1) NOT NULL DEFAULT '1',
  `name` varchar(255) NOT NULL DEFAULT '0',
  `admin_zone` tinyint(1) NOT NULL DEFAULT '0',
  `product` tinyint(1) NOT NULL DEFAULT '0',
  `page` tinyint(1) NOT NULL DEFAULT '0',
  `category` tinyint(1) NOT NULL DEFAULT '0',
  `order` tinyint(1) DEFAULT '0',
  `user` tinyint(1) NOT NULL DEFAULT '0',
  `plugin` tinyint(1) NOT NULL DEFAULT '0',
  `setting` tinyint(1) NOT NULL DEFAULT '0',
  `wholesales` tinyint(1) NOT NULL DEFAULT '0',
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

CREATE TABLE `mg_vk-export` (
  `moguta_id` int(11) NOT NULL,
  `vk_id` varchar(255) NOT NULL,
  `moguta_img` varchar(255) NOT NULL,
  `vk_img` varchar(255) NOT NULL,
  PRIMARY KEY (`moguta_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE `mg_wholesales_sys` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `variant_id` int(11) NOT NULL,
  `count` int(11) NOT NULL,
  `price` double NOT NULL DEFAULT '0',
  `group` int(11) DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`),
  KEY `variant_id` (`variant_id`),
  KEY `count` (`count`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE `mg_yandexmarket` (
  `name` varchar(255) NOT NULL,
  `settings` longtext NOT NULL,
  `edited` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;



INSERT INTO `mg_setting` VALUES
("1","sitename","localhost","Y","SITE_NAME"),
("2","adminEmail","admin@mail.ru","Y","EMAIL_ADMIN"),
("3","templateName","moguta","Y","SITE_TEMPLATE"),
("4","countСatalogProduct","6","Y","CATALOG_COUNT_PAGE"),
("5","currency","руб.","Y","SETTING_CURRENCY"),
("6","staticMenu","true","N","SETTING_STATICMENU"),
("7","orderMessage","Оформлен заказ № #ORDER# на сайте #SITE#","Y","TPL_EMAIL_ORDER"),
("8","downtime","false","N","DOWNTIME_SITE"),
("9","currentVersion","{\"dateActivateKey\":\"0000-00-00 00:00:00\",\"key_to_lite_edition\":0,\"edition\":\"\",\"keyDaysRemaining\":\"error\",\"notifications\":[]}","N","INFO_CUR_VERSION"),
("10","timeLastUpdata","IcGOLaurnijZQvywTEXsQlykTjXnuunXjTQy","N","LASTTIME_UPDATE"),
("11","title"," Лучший магазин | Moguta.CMS","N","SETTING_PAGE_TITLE"),
("12","countPrintRowsProduct","20","Y","ADMIN_COUNT_PROD"),
("13","languageLocale","ru_RU","N","ADMIN_LANG_LOCALE"),
("14","countPrintRowsPage","10","Y","ADMIN_COUNT_PAGE"),
("15","themeColor","green-theme","N","ADMIN_THEM_COLOR"),
("16","themeBackground","bg_7","N","ADMIN_THEM_BG"),
("17","countPrintRowsOrder","20","N","ADMIN_COUNT_ORDER"),
("18","countPrintRowsUser","30","N","ADMIN_COUNT_USER"),
("19","licenceKey","4c9684a4f33b869f5c651240c5c3105e","N","LICENCE_KEY"),
("20","mainPageIsCatalog","true","Y","SETTING_CAT_ON_INDEX"),
("21","countNewProduct","5","Y","COUNT_NEW_PROD"),
("22","countRecomProduct","5","Y","COUNT_RECOM_PROD"),
("23","countSaleProduct","5","Y","COUNT_SALE_PROD"),
("24","actionInCatalog","true","Y","VIEW_OR_BUY"),
("25","printProdNullRem","true","Y","PRINT_PROD_NULL_REM"),
("26","printRemInfo","true","Y","PRINT_REM_INFO"),
("27","heightPreview","348","Y","PREVIEW_HEIGHT"),
("28","widthPreview","540","Y","PREVIEW_WIDTH"),
("29","heightSmallPreview","200","Y","PREVIEW_HEIGHT_2"),
("30","widthSmallPreview","300","Y","PREVIEW_WIDTH_2"),
("31","waterMark","false","Y","WATERMARK"),
("32","widgetCode","<!-- В это поле необходимо прописать код счетчика посещаемости Вашего сайта. Например, Яндекс.Метрика или Google analytics -->","Y","WIDGETCODE"),
("33","noReplyEmail","noreply@sitename.ru","Y","NOREPLY_EMAIL"),
("34","smtp","false","Y","SMTP"),
("35","smtpHost","","Y","SMTP_HOST"),
("36","smtpLogin","admin@mail.ru","Y","SMTP_LOGIN"),
("37","smtpPass","MTIzNDU1NDMyMWhZKjZuazchISMycWo=","Y","SMTP_PASS"),
("38","smtpPort","","Y","SMTP_PORT"),
("39","shopPhone","8 (555) 555-55-55","Y","SHOP_PHONE"),
("40","shopAddress","г. Кемерово, ул. Тверская, 1.","Y","SHOP_ADDERSS"),
("41","shopName","Интернет-магазин VELOVEL","Y","SHOP_NAME"),
("42","shopLogo","/uploads/logo/logo.jpg","Y","SHOP_LOGO"),
("43","phoneMask","+7 (###) ### ##-##,+380 (##) ### ##-##,+375 (##) ### ##-##","Y","PHONE_MASK"),
("44","printStrProp","false","Y","PROP_STR_PRINT"),
("45","noneSupportOldTemplate","false","Y","OLD_TEMPLATE"),
("46","printCompareButton","true","Y","BUTTON_COMPARE"),
("47","currencyShopIso","RUR","Y","CUR_SHOP_ISO"),
("48","cacheObject","true","Y","CACHE_OBJECT"),
("49","cacheMode","DB","Y","CACHE_MODE"),
("50","cacheTime","86400","Y","CACHE_TIME"),
("51","cacheHost","","Y","CACHE_HOST"),
("52","cachePort","","Y","CACHE_PORT"),
("53","priceFormat","1 234,56","Y","PRICE_FORMAT"),
("54","horizontMenu","false","Y","HORIZONT_MENU"),
("55","buttonBuyName","Купить","Y","BUTTON_BUY_NAME"),
("56","buttonCompareName","Сравнить","Y","BUTTON_COMPARE_NAME"),
("57","randomProdBlock","false","Y","RANDOM_PROD_BLOCK"),
("58","timeStartEngine","1543415427","N","TIME_START_ENGINE"),
("59","timeFirstUpdate","","N","TIME_START_ENGINE"),
("60","buttonMoreName","Подробнее","Y","BUTTON_MORE_NAME"),
("61","compareCategory","true","Y","COMPARE_CATEGORY"),
("62","colorScheme","ef4746","Y","COLOR_SCHEME"),
("63","useCaptcha","false","Y","USE_CAPTCHA"),
("64","autoRegister","true","Y","AUTO_REGISTER"),
("65","printFilterResult","true","Y","FILTER_RESULT"),
("66","dateActivateKey ","0000-00-00 00:00:00","N",""),
("67","propertyOrder","a:16:{s:7:\"nameyur\";s:40:\"ООО \"Интернет-магазин\"\";s:6:\"adress\";s:48:\"г.Москва ул. Тверская, дом 1\";s:3:\"inn\";s:10:\"8805614058\";s:3:\"kpp\";s:9:\"980501000\";s:4:\"ogrn\";s:13:\"7137847078193\";s:4:\"bank\";s:16:\"Сбербанк\";s:3:\"bik\";s:9:\"041012721\";s:2:\"ks\";s:20:\"40702810032030000834\";s:2:\"rs\";s:20:\"30101810600000000957\";s:7:\"general\";s:48:\"Михаил Васильевич Могутов\";s:4:\"sing\";s:0:\"\";s:5:\"stamp\";s:0:\"\";s:3:\"nds\";s:2:\"18\";s:8:\"usedsing\";s:4:\"true\";s:6:\"prefix\";s:3:\"MG_\";s:8:\"currency\";s:34:\"рубль,рубля,рублей\";}","N",""),
("68","enabledSiteEditor","false","N",""),
("69","lockAuthorization","false","Y","LOCK_AUTH"),
("70","orderNumber","true","Y","ORDER_NUMBER"),
("71","popupCart","true","Y","POPUP_CART"),
("72","catalogIndex","false","Y","CATALOG_INDEX"),
("73","productInSubcat","true","Y","PRODUCT_IN_SUBCAT"),
("74","copyrightMoguta","true","Y","COPYRIGHT_MOGUTA"),
("75","picturesCategory","true","Y","PICTURES_CATEGORY"),
("76","requiredFields","true","Y","REQUIRED_FIELDS"),
("77","backgroundSite","/uploads/logo/fon.jpg","Y","BACKGROUND_SITE"),
("78","waterMarkVariants","false","Y","WATERMARK_VARIANTS"),
("79","cacheCssJs","false","Y","CACHE_CSS_JS"),
("80","categoryImgWidth","200","Y","CATEGORY_IMG_WIDTH"),
("81","categoryImgHeight","200","Y","CATEGORY_IMG_HEIGHT"),
("82","favicon","","Y","FAVICON"),
("83","connectZoom","true","Y","CONNECT_ZOOM"),
("84","filterSort","price_course|asc","Y","FILTER_SORT"),
("85","shortLink","false","Y","SHORT_LINK"),
("86","imageResizeType","PROPORTIONAL","Y","IMAGE_RESIZE_TYPE"),
("87","imageSaveQuality","75","Y","IMAGE_SAVE_QUALITY"),
("88","duplicateDesc","false","Y","DUPLICATE_DESC"),
("89","excludeUrl","","Y","EXCLUDE_SITEMAP"),
("90","autoGeneration","false","Y","AUTO_GENERATION"),
("91","generateEvery","2","Y","GENERATE_EVERY"),
("92","consentData","true","Y","CONSENT_DATA"),
("93","showCountInCat","true","Y","SHOW_COUNT_IN_CAT"),
("94","nameOfLinkyml","getyml","N","NAME_OF_LINKYML"),
("95","clearCatalog1C","false","Y","CLEAR_1C_CATALOG"),
("96","fileLimit1C","10000000","Y","FILE_LIMIT_1C"),
("97","notUpdateDescription1C","true","Y","UPDATE_DESCRIPTION_1C"),
("98","notUpdateImage1C","true","Y","UPDATE_IMAGE_1C"),
("99","showSortFieldAdmin","false","Y","SHOW_SORT_FIELD_ADMIN"),
("100","filterSortVariant","price_course|asc","Y","FILTER_SORT_VARIANT");
INSERT INTO `mg_setting` VALUES
("101","showVariantNull","true","Y","SHOW_VARIANT_NULL"),
("102","confirmRegistration","true","Y","CONFIRM_REGISTRATION"),
("103","cachePrefix","","Y","CACHE_PREFIX"),
("104","usePhoneMask","true","Y","USE_PHONE_MASK"),
("105","smtpSsl","false","Y","SMTP_SSL"),
("106","sessionToDB","false","Y","SAVE_SESSION_TO_DB"),
("107","sessionLifeTime","1440","Y","SESSION_LIVE_TIME"),
("108","sessionAutoUpdate","true","Y","SESSION_AUTO_UPDATE"),
("109","showCodeInCatalog","false","Y","SHOW_CODE_IN_CATALOG"),
("110","openGraph","true","Y","OPEN_GRAPH"),
("111","dublinCore","true","Y","DUBLIN_CORE"),
("112","printSameProdNullRem","true","Y","PRINT_SAME_PROD_NULL_REM"),
("113","landingName","lp-moguta","N",""),
("114","colorSchemeLanding","none","N",""),
("115","printQuantityInMini","false","Y","SHOW_QUANTITY"),
("116","printCurrencySelector","false","Y","CURRENCY_SELECTOR"),
("117","interface","a:5:{s:9:\"colorMain\";s:7:\"#2773eb\";s:9:\"colorLink\";s:7:\"#1585cf\";s:9:\"colorSave\";s:7:\"#4caf50\";s:11:\"colorBorder\";s:7:\"#e6e6e6\";s:14:\"colorSecondary\";s:7:\"#ebebeb\";}","Y",""),
("118","filterCountProp","3","Y","FILTER_COUNT_PROP"),
("119","filterMode","true","Y","FILTER_MODE"),
("120","filterSubcategory","false","Y","FILTER_SUBCATGORY"),
("121","printVariantsInMini","false","Y","SHOW_VARIANT_MINI"),
("122","useReCaptcha","false","Y","USE_RECAPTCHA"),
("123","reCaptchaKey","","Y","RECAPTCHA_KEY"),
("124","reCaptchaSecret","","Y","RECAPTCHA_SECRET"),
("125","timeWork","09:00 - 19:00,10:00 - 17:00","Y","TIME_WORK"),
("126","useSeoRewrites","false","Y","SEO_REWRITES"),
("127","useSeoRedirects","false","Y","SEO_REDIRECTS"),
("128","showMainImgVar","false","Y","SHOW_MAIN_IMG_VAR"),
("129","loginAttempt","5","Y","LOGIN_ATTEMPT"),
("130","prefixOrder","M-010","Y","PREFIX_ORDER"),
("131","captchaOrder","false","Y","CAPTCHA_ORDER"),
("132","deliveryZero","true","Y","DELIVERY_ZERO"),
("133","outputMargin","true","Y","OUTPUT_MARGIN"),
("134","prefixCode","CN","Y","PREFIX_CODE"),
("135","maxUploadImgWidth","1500","Y","MAX_UPLOAD_IMAGE_WIDTH"),
("136","maxUploadImgHeight","1500","Y","MAX_UPLOAD_IMAGE_HEIGHT"),
("137","searchType","like","Y","SEARCH_TYPE"),
("138","searchSphinxHost","localhost","Y","SEARCH_SPHINX_HOST"),
("139","searchSphinxPort","9312","Y","SEARCH_SPHINX_PORT"),
("140","checkAdminIp","false","Y","CHECK_ADMIN_IP"),
("141","printSeo","all","Y","PRINT_SEO"),
("142","catalogProp","0","Y","CATALOG_PROP"),
("143","printAgreement","true","Y","PRINT_AGREEMENT"),
("144","currencyShort","a:7:{s:3:\\\"BTC\\\";s:3:\\\"btc\\\";s:3:\\\"RUR\\\";s:7:\\\"руб.\\\";s:3:\\\"UAH\\\";s:7:\\\"грн.\\\";s:3:\\\"USD\\\";s:1:\\\"$\\\";s:3:\\\"EUR\\\";s:3:\\\"€\\\";s:3:\\\"KZT\\\";s:10:\\\"тенге\\\";s:3:\\\"UZS\\\";s:6:\\\"сум\\\";}","Y","CUR_SHOP_SHORT"),
("145","useElectroLink","false","Y","USE_ELECTRO_LINK"),
("146","currencyActive","a:0:{}","Y",""),
("147","closeSite","false","Y","CLOSE_SITE_1C"),
("148","catalogPreCalcProduct","old","Y","CATALOG_PRE_CALC_PRODUCT"),
("149","printSpecFilterBlock","true","Y","FILTER_PRINT_SPEC"),
("150","disabledPropFilter","false","Y","DISABLED_PROP_FILTER"),
("151","enableDeliveryCur","false","Y","ENABLE_DELIVERY_CUR"),
("152","addDateToImg","true","Y","ADD_DATE_TO_IMG"),
("153","variantToSize1c","false","Y","VARIANT_TO_SIZE_1C"),
("154","sphinxLimit","20","Y","SPHINX_LIMIT"),
("155","filterCatalogMain","false","Y","FILTER_CATALOG_MAIN"),
("156","importColorSize","size","Y","IMPORT_COLOR_SIZE"),
("157","sizeName1c","Размер","Y","SIZE_NAME_1C"),
("158","colorName1c","Цвет","Y","COLOR_NAME_1C"),
("159","sizeMapMod","COLOR","Y","SIZE_MAP_MOD"),
("160","modParamInVarName","true","Y","MOD_PARAM_IN_VAR_NAME"),
("161","catalog_meta_title","{titeCategory}","N",""),
("162","catalog_meta_description","{cat_desc,160}","N",""),
("163","catalog_meta_keywords","{meta_keywords}","N",""),
("164","product_meta_title","{title}","N",""),
("165","product_meta_description","{title} за {price} {currency} купить. {description,100}","N",""),
("166","product_meta_keywords","{meta_keywords}","N",""),
("167","page_meta_title","{title}","N",""),
("168","page_meta_description","{html_content,160}","N",""),
("169","page_meta_keywords","{meta_keywords}","N",""),
("170","currencyRate","a:7:{s:3:\\\"BTC\\\";i:1;s:3:\\\"RUR\\\";i:1;s:3:\\\"UAH\\\";i:1;s:3:\\\"USD\\\";i:1;s:3:\\\"EUR\\\";i:1;s:3:\\\"KZT\\\";i:1;s:3:\\\"UZS\\\";i:1;}","Y","CUR_SHOP_RATE"),
("171","lastModVersion","v8.2.2","N",""),
("172","lastTimeCacheClear","1544542682","N",""),
("173","chimpApiKey","IeGqLougnYjwQEysTlXkQXyTTyXQujnnjuQXyT","N",""),
("174","trialVersion","Для активации CMS получите БЕСПЛАТНЫЙ лицензионный ключ в личном кабинете на сайте moguta.ru. Без ключа демонстрационная версия будет работать только 8 дней. Ключ не существует!","N",""),
("175","imageDropTimer","1544629186","N",""),
("176","notifInfo","","N",""),
("177","updateDB","2","N",""),
("178","mpError","Введен некорректный лицензионный ключ","N",""),
("179","mpUpdate","IwGELsulnkjMQfyNTJXwQEysTlXkujnnjuQXyT","N",""),
("180","sliderActionOption","a:8:{s:5:\\\"width\\\";s:4:\\\"1130\\\";s:6:\\\"height\\\";s:3:\\\"248\\\";s:5:\\\"speed\\\";s:0:\\\"\\\";s:5:\\\"pause\\\";s:0:\\\"\\\";s:4:\\\"mode\\\";s:8:\\\"vertical\\\";s:8:\\\"position\\\";s:4:\\\"left\\\";s:11:\\\"titleslider\\\";s:0:\\\"\\\";s:10:\\\"nameaction\\\";s:5:\\\"false\\\";}","N",""),
("181","pluginsVersionInfo","a:0:{}","N","");




INSERT INTO `mg_brand-logo` VALUES
("3","Bongo","http://sp.ru/uploads/logo/log10.png","","0","","",""),
("5","Mozza","http://sp.ru/uploads/logo/log8.png","","0","","",""),
("7","Samsung","http://sp.ru/uploads/logo/log6.png","","0","Samsung","Samsung","Samsung"),
("9","Apple","http://sp.ru/uploads/logo/log4.png","","0","","","");

INSERT INTO `mg_category` VALUES
("21","2","3","1","Велосипеды","Велосипеды","velosipedy","0","","21","","","","","0","","\\uploads\\category\\21\\Giant-XtC-SL-Jr-24-2018_2018-11-30_19-04-40.jpg","","0","1","","1","шт.","","","0"),
("22","4","5","1","Велоаксессуары","Велоаксессуары","veloaksessuary","0","","22","","","","","0","","\\uploads\\category\\22\\tros-zamok-GK101708_2018-11-30_19-05-08.jpg","","0","1","","1","шт.","","","0"),
("23","6","7","1","Защита","Защита","zaschita","0","","23","","","","","0","","\\uploads\\category\\23\\shlem-zaschitnyy-MV-16_2018-11-30_18-57-15.jpg","","0","1","","1","шт.","","","0"),
("24","8","9","1","Велоодежда","Велоодежда","veloodejda","0","","24","","","","","0","","\\uploads\\category\\24\\kombinezon-Verducci-Racing_2018-11-30_19-01-07.jpg","","0","1","","1","шт.","","","0"),
("25","10","11","1","Инструменты","Инструменты","instrumenty","0","","25","","","","","0","","\\uploads\\category\\25\\nabor-instrumentov-Park-Tool-MK-222_2018-11-30_18-59-11.jpg","","0","1","","1","шт.","","","0");




INSERT INTO `mg_delivery` VALUES
("1","Курьер","700","Курьерская служба","1","0","1","1","1","","","","0"),
("2","Почта","200","Почта России","1","0","0","2","0","","","","0"),
("3","Без доставки","0","Самовывоз","1","0","0","3","0","","","","0");

INSERT INTO `mg_delivery_payment_compare` VALUES
("1","1","1"),
("5","1","1"),
("2","2","1"),
("3","1","1"),
("1","2","1"),
("2","1","1"),
("3","2","1"),
("4","2","1"),
("4","3","1"),
("3","3","1"),
("2","3","1"),
("1","3","1"),
("4","1","1"),
("5","2","1"),
("6","1","1"),
("6","2","1"),
("6","3","1"),
("5","3","1"),
("7","1","1"),
("7","2","1"),
("7","3","1"),
("8","1","1"),
("8","2","1"),
("8","3","1"),
("9","1","1"),
("9","2","1"),
("9","3","1"),
("10","1","1"),
("10","2","1"),
("10","3","1");





INSERT INTO `mg_messages` VALUES
("1","msg__order_denied","Для просмотра страницы необходимо зайти на сайт под пользователем сделавшим заказ №#NUMBER#.","Для просмотра страницы необходимо зайти на сайт под пользователем сделавшим заказ №#NUMBER#.","order"),
("2","msg__no_electro","Заказ не содержит электронных товаров или ожидает оплаты!","Заказ не содержит электронных товаров или ожидает оплаты!","order"),
("3","msg__electro_download","Скачать электронные товары для заказа №#NUMBER#.","Скачать электронные товары для заказа №#NUMBER#.","order"),
("4","msg__view_status","Посмотреть статус заказа Вы можете в <a href=\"#LINK#\">личном кабинете</a>.","Посмотреть статус заказа Вы можете в <a href=\"#LINK#\">личном кабинете</a>.","order"),
("5","msg__order_not_found","Некорректная ссылка.<br> Заказ не найден.<br>","Некорректная ссылка.<br> Заказ не найден.<br>","order"),
("6","msg__view_order","Следить за статусом заказа Вы можете по ссылке<br><a href=\"#LINK#\">#LINK#</a>.","Следить за статусом заказа Вы можете по ссылке<br><a href=\"#LINK#\">#LINK#</a>.","order"),
("7","msg__order_confirmed","Ваш заказ №#NUMBER# подтвержден и передан на обработку.<br>","Ваш заказ №#NUMBER# подтвержден и передан на обработку.<br>","order"),
("8","msg__order_processing","Заказ уже подтвержден и находится в работе.<br>","Заказ уже подтвержден и находится в работе.<br>","order"),
("9","msg__order_not_confirmed","Некорректная ссылка.<br>Заказ не подтвержден.<br>","Некорректная ссылка.<br>Заказ не подтвержден.<br>","order"),
("10","msg__email_in_use","Пользователь с таким email существует. Пожалуйста, <a href=\"#LINK#\">войдите в систему</a> используя свой электронный адрес и пароль!","Пользователь с таким email существует. Пожалуйста, <a href=\"#LINK#\">войдите в систему</a> используя свой электронный адрес и пароль!","order"),
("11","msg__email_incorrect","E-mail введен некорректно!","E-mail введен некорректно!","order"),
("12","msg__phone_incorrect","Введите верный номер телефона!","Введите верный номер телефона!","order"),
("13","msg__payment_incorrect","Выберите способ оплаты!","Выберите способ оплаты!","order"),
("15","msg__product_ended","Товара #PRODUCT# уже нет в наличии. Для оформления заказа его необходимо удалить из корзины.","Товара #PRODUCT# уже нет в наличии. Для оформления заказа его необходимо удалить из корзины.","product"),
("16","msg__product_ending","Товар #PRODUCT# доступен в количестве #COUNT# шт. Для оформления заказа измените количество в корзине.","Товар #PRODUCT# доступен в количестве #COUNT# шт. Для оформления заказа измените количество в корзине.","product"),
("17","msg__no_compare","Нет товаров для сравнения в этой категории.","Нет товаров для сравнения в этой категории.","product"),
("18","msg__product_nonavaiable1","Товара временно нет на складе!<br/><a rel=\"nofollow\" href=\"#LINK#\">Сообщить когда будет в наличии.</a>","Товара временно нет на складе!<br/><a rel=\"nofollow\" href=\"#LINK#\">Сообщить когда будет в наличии.</a>","product"),
("19","msg__product_nonavaiable2","Здравствуйте, меня интересует товар #PRODUCT# с артикулом #CODE#, но его нет в наличии. Сообщите, пожалуйста, о поступлении этого товара на склад. ","Здравствуйте, меня интересует товар #PRODUCT# с артикулом #CODE#, но его нет в наличии. Сообщите, пожалуйста, о поступлении этого товара на склад. ","product"),
("20","msg__enter_failed","Неправильная пара email-пароль! Авторизоваться не удалось.","Неправильная пара email-пароль! Авторизоваться не удалось.","register"),
("21","msg__enter_captcha_failed","Неправильно введен код с картинки! Авторизоваться не удалось. Количество оставшихся попыток - #COUNT#.","Неправильно введен код с картинки! Авторизоваться не удалось. Количество оставшихся попыток - #COUNT#.","register"),
("22","msg__enter_blocked","В целях безопасности возможность авторизации заблокирована на 15 мин. Отсчет времени от #TIME#.","В целях безопасности возможность авторизации заблокирована на 15 мин. Отсчет времени от #TIME#.","register"),
("23","msg__enter_field_missing","Одно из обязательных полей не заполнено!","Одно из обязательных полей не заполнено!","register"),
("24","msg__feedback_sent","Ваше сообщение отправлено!","Ваше сообщение отправлено!","feedback"),
("25","msg__feedback_wrong_email","E-mail не существует!","E-mail не существует!","feedback"),
("26","msg__feedback_no_text","Введите текст сообщения!","Введите текст сообщения!","feedback"),
("27","msg__captcha_incorrect","Текст с картинки введен неверно!","Текст с картинки введен неверно!","feedback"),
("28","msg__reg_success_email","Вы успешно зарегистрировались! Для активации пользователя Вам необходимо перейти по ссылке высланной на Ваш электронный адрес <strong>#EMAIL#</strong>","Вы успешно зарегистрировались! Для активации пользователя Вам необходимо перейти по ссылке высланной на Ваш электронный адрес <strong>#EMAIL#</strong>","register"),
("29","msg__reg_success","Вы успешно зарегистрировались! <a href=\"#LINK#\">Вход в личный кабинет</a></strong>","Вы успешно зарегистрировались! <a href=\"#LINK#\">Вход в личный кабинет</a></strong>","register"),
("30","msg__reg_activated","Ваша учетная запись активирована. Теперь Вы можете <a href=\"#LINK#\">войти в личный кабинет</a> используя логин и пароль заданный при регистрации.","Ваша учетная запись активирована. Теперь Вы можете <a href=\"#LINK#\">войти в личный кабинет</a> используя логин и пароль заданный при регистрации.","register"),
("31","msg__reg_wrong_link","Некорректная ссылка. Повторите активацию!","Некорректная ссылка. Повторите активацию!","register"),
("32","msg__reg_link","Для активации пользователя Вам необходимо перейти по ссылке высланной на Ваш электронный адрес #EMAIL#","Для активации пользователя Вам необходимо перейти по ссылке высланной на Ваш электронный адрес #EMAIL#","register"),
("33","msg__wrong_login","К сожалению, такой логин не найден. Если вы уверены, что данный логин существует, свяжитесь, пожалуйста, с нами.","К сожалению, такой логин не найден. Если вы уверены, что данный логин существует, свяжитесь, пожалуйста, с нами.","register"),
("34","msg__reg_email_in_use","Указанный email уже используется.","Указанный email уже используется.","register"),
("35","msg__reg_short_pass","Пароль менее 5 символов.","Пароль менее 5 символов.","register"),
("36","msg__reg_wrong_pass","Введенные пароли не совпадают.","Введенные пароли не совпадают.","register"),
("37","msg__reg_wrong_email","Неверно заполнено поле email","Неверно заполнено поле email","register"),
("38","msg__forgot_restore","Инструкция по восстановлению пароля была отправлена на <strong>#EMAIL#</strong>.","Инструкция по восстановлению пароля была отправлена на <strong>#EMAIL#</strong>.","register"),
("39","msg__forgot_wrong_link","Некорректная ссылка. Повторите заново запрос восстановления пароля.","Некорректная ссылка. Повторите заново запрос восстановления пароля.","register"),
("40","msg__forgot_success","Пароль изменен! Вы можете войти в личный кабинет по адресу <a href=\"#LINK#\">#LINK#</a>","Пароль изменен! Вы можете войти в личный кабинет по адресу <a href=\"#LINK#\">#LINK#</a>","register"),
("41","msg__pers_saved","Данные успешно сохранены","Данные успешно сохранены","register"),
("42","msg__pers_wrong_pass","Неверный пароль","Неверный пароль","register"),
("43","msg__pers_pass_changed","Пароль изменен","Пароль изменен","register"),
("44","msg__recaptcha_incorrect","reCAPTCHA не пройдена!","reCAPTCHA не пройдена!","feedback"),
("45","msg__enter_recaptcha_failed","reCAPTCHA не пройдена! Авторизоваться не удалось. Количество оставшихся попыток - #COUNT#.","reCAPTCHA не пройдена! Авторизоваться не удалось. Количество оставшихся попыток - #COUNT#.","register"),
("46","msg__status_not_confirmed","не подтвержден","не подтвержден","status"),
("47","msg__status_expects_payment","ожидает оплаты","ожидает оплаты","status"),
("48","msg__status_paid","оплачен","оплачен","status"),
("49","msg__status_in_delivery","в доставке","в доставке","status"),
("50","msg__status_canceled","отменен","отменен","status"),
("51","msg__status_executed","выполнен","выполнен","status"),
("52","msg__status_processing","в обработке","в обработке","status"),
("53","msg__payment_inn","Заполните ИНН","Заполните ИНН","order");



INSERT INTO `mg_page` VALUES
("1","","0","Главная","index","<h3 style=\"text-align: center;\">\n	<span style=\"color:#FF0000;\"><span style=\"font-size:28px;\"><strong>Добро пожаловать в наш интернет-магазин!</strong></span></span>\n</h3>\n\n<div>\n	<p>\n		<span style=\"color:#FF0000;\"><span style=\"font-size:24px;\">Компания VELOVEL.RU&nbsp; основана в&nbsp;2008 году.&nbsp;Cегодня мы&nbsp;являемся крупнейшим в Кемеровской области&nbsp;и&nbsp;России продавцом велосипедов, запчастей и&nbsp;аксессуаров.</span></span>\n	</p>\n\n	<p>\n		<span style=\"color:#FF0000;\"><span style=\"font-size:24px;\">Для нас очень важна деловая репутация&nbsp;— мы&nbsp;отвечаем за&nbsp;то, что продаем и&nbsp;стараемся идти клиенту навстречу в&nbsp;решении любых спорных ситуаций. Наши товары и&nbsp;услуги высоко оцениваются не&nbsp;только среди потребителей, но&nbsp;и&nbsp;в&nbsp;профессиональном кругу. Подтверждением этому служит обширная база постоянных клиентов и&nbsp;дипломы, полученные на&nbsp;выставках. Мы&nbsp;даем гарантию на&nbsp;каждый проданный нами велосипед.</span></span><br />\n		&nbsp;\n	</p>\n</div>\n<script type=\"text/javascript\" src=\"https://vk.com/js/api/openapi.js?160\"></script><!-- VK Widget -->\n\n<div id=\"vk_subscribe\">\n	&nbsp;\n</div>\n<script type=\"text/javascript\">\nVK.Widgets.Subscribe(\"vk_subscribe\", {soft: 1}, -174885227);\n</script>","Главная","Главная","","5","0","1"),
("2","","0","Доставка и оплата","dostavka","<div>\n	<h1 class=\"new-products-title\">\n		Доставка и оплата\n	</h1>\n\n	<p>\n		<strong>Курьером по Кемерово</strong>\n	</p>\n\n	<p>\n		Доставка осуществляется по Кемерово бесплатно, если сумма заказа составляет свыше 3000 руб. Стоимость доставки меньше чем на сумму 3000 руб. Составляет 700 руб. Данный способ доставки дает вам возможность получить товар прямо в руки, курьером по Кемерово. Срок доставки до 24 часов с момента заказа товара в интернет - магазине.\n	</p>\n\n	<p>\n		<strong>Доставка по России</strong>\n	</p>\n\n	<p>\n		Доставка по России осуществляется с помощью почтово – курьерских служб во все регионы России. Стоимость доставки зависит от региона и параметров товара. Рассчитать стоимость доставки Вы сможете на официальном сайте почтово – курьерской службы Почта-России и т.д. Сроки доставки составляет до 3-х дней с момента заказа товара в интернет – магазине.\n	</p>\n\n	<h2>\n		Способы оплаты:\n	</h2>\n\n	<p>\n		<strong>Наличными: </strong>Оплатить заказ товара Вы сможете непосредственно курьеру в руки при получение товара.\n	</p>\n\n	<p>\n		<strong>Наложенным платежом:</strong> Оплатить заказ товара Вы сможете наложенным платежом при получение товара на складе. С данным видом оплаты Вы оплачиваете комиссию за пересылку денежных средств.\n	</p>\n\n	<p>\n		<strong>Электронными деньгами:</strong> VISA, Master Card, Yandex.Деньги, Webmoney, Qiwi и др.\n	</p>\n</div>\n\n<div>\n	&nbsp;\n</div>\n\n<div>\n	&nbsp;\n</div>\n\n<div>\n	&nbsp;\n</div>","Доставка","Доставка","Доставка осуществляется по Москве бесплатно, если сумма заказа составляет свыше 3000 руб.  Стоимость доставки меньше чем на сумму 3000 руб. Составляет 700 руб.","2","1","0"),
("3","","0","Обратная связь","feedback","<p>\n	Свяжитесь с нами, посредством формы обратной связи представленной ниже. Вы можете задать любой вопрос, и после отправки сообщения наш менеджер свяжется с вами.\n</p>","Обратная связь","Обратная связь","Свяжитесь с нами, по средствам формы обратной связи представленной ниже. Вы можете задать любой вопрос, и после отправки сообщения наш менеджер свяжется с вами.","3","1","0"),
("4","","0","Контакты","contacts","<h1 class=\"new-products-title\">\n	Контакты\n</h1>\n\n<p>\n	<strong>Наш адрес </strong>г. Кемерово ул.Арочная 39\n</p>\n\n<p>\n	<strong>Телефон отдела продаж </strong>8 (555) 555-55-55\n</p>\n\n<p>\n	Пн-Пт 9.00 - 19.00\n</p>\n\n<p>\n	Электронный ящик: velovel<span style=\"line-height: 1.6em;\">@sale.ru</span>\n</p>\n\n<p>\n	<strong>Мы в социальных сетях</strong><br />\n	&nbsp;\n</p>\n<script type=\"text/javascript\" src=\"https://vk.com/js/api/openapi.js?160\"></script>\n\n<div id=\"vk_subscribe\">\n	&nbsp;\n</div>\n<script type=\"text/javascript\">\nVK.Widgets.Subscribe(\"vk_subscribe\", {soft: 1}, -174885227);\n</script>","Контакты","Контакты","Мы в социальных сетях  Мы в youtoube","4","1","0"),
("5","","0","Каталог","catalog","В каталоге нашего магазина вы найдете не только качественные и полезные вещи, но и абсолютно уникальные новинки из мира цифровой индустрии.","Каталог","Каталог","","1","1","0");

INSERT INTO `mg_payment` VALUES
("3","Наложенный платеж","1","{\"Примечание\":\"\"}","","0","3","017ded308104a58aae73bae77ba57a48","fiz"),
("4","Наличные (курьеру)","1","{\"Примечание\":\"\"}","","0","4","017ded308104a58aae73bae77ba57a48","fiz"),
("7","Оплата по реквизитам","1","{\"Юридическое лицо\":\"\", \"ИНН\":\"\",\"КПП\":\"\", \"Адрес\":\"\", \"Банк получателя\":\"\", \"БИК\":\"\",\"Расчетный счет\":\"\",\"Кор. счет\":\"\"}","","0","7","017ded308104a58aae73bae77ba57a48","yur"),
("12","Другой способ оплаты","1","{\"Примечание\":\"\"}","","0","16","017ded308104a58aae73bae77ba57a48","fiz"),
("13","Другой способ оплаты","1","{\"Примечание\":\"\"}","","0","17","017ded308104a58aae73bae77ba57a48","fiz");

INSERT INTO `mg_plugins` VALUES
("breadcrumbs","1"),
("site-block-editor","1"),
("adaptizator","0"),
("brand","0"),
("comments","1"),
("slider-action","1"),
("trigger-guarantee","1"),
("rating","1");

INSERT INTO `mg_product` VALUES
("65","65","25","Велоаптечка YC-129A","Аптечка 6 заплаток, клей 5 мл, зачистка и 2 монтажки, в пластиковой коробочке. Данный набор, позволит быстро заклеить велокамеру, монтажки помогут легко разбортировать колесо без особых навыков.<br />\n&nbsp;","160","veloaptechka-yc-129a","veloaptechka-YC-129A_2018-11-30_18-58-21.JPG","CN65","-1","1","","","","","0","0","","","","0","","RUR","160","","","","","1","","","2018-11-30 22:58:25","шт."),
("63","63","23","Велозащита Polisport Titan 07","Polisport Titan 07- это прочная надежная шарнирная полипропиленовая велозащита. Рассчитана на агрессивный стиль велокатания \"фрирайд\" и \"даунхилл\". Надевается через голову, фиксируется при помощи удобных ремешков-стяжек в поясной области. Цвет: белый, красный, серый.<br />\n<strong>Марка</strong><br />\nPolisport<br />\n<strong>Модель</strong><br />\nTitan 07<br />\n<strong>Материал</strong><br />\nполипропилен<br />\n<strong>Особенности</strong><br />\nзащита груди, спины и плечей<br />\n<strong>Цвета (выпускаемые)</strong><br />\nбелый, красный, серый<br />\n&nbsp;","3000","velozaschita-polisport-titan-07","velozaschita-Polisport-Titan-07_2018-11-30_18-56-47.jpg","CN63","-1","1","","","","","0","0","","","","0","","RUR","3000","","","","","1","","","2018-11-30 22:56:50","шт."),
("64","64","23","Шлем защитный MV 16","MTV 16 - универсальный шлем, сделан для защиты головы при езде на байке, скейтбордах, роликовых коньках и т.д. Всего вентиляционных отверстий 16, выполнен по технологии In-Mold - верхний и внутренний слой сплавлены друг с другом, что делает конструкцию максимально прочной и легкой. Размер М (56-58 см), L (58-60 см). Вес - 290 г. Цвет: бело-синий<br />\n&nbsp;<br />\n<strong>Особенности</strong><br />\n16 ветиляционных отверстий<br />\n<strong>Размеры (выпускаемые)</strong><br />\nМ (56-58 см), L (58-60 см)<br />\n<strong>Вес</strong><br />\n290 г<br />\n<strong>Цвета (выпускаемые)</strong><br />\nбело-синий<br />\n&nbsp;","2300","shlem-zaschitnyy-mv-16","shlem-zaschitnyy-MV-16_2018-11-30_18-57-15.jpg","CN64","-1","1","","","","","0","0","","","","0","","RUR","2300","","","","","1","","","2018-11-30 22:57:22","шт."),
("61","61","21","Schwinn Hollywood 2015","Динамика Schwinn Hollywood 2015 завораживает. Вы словно скользите по морским волнам, оставляя за бортом суету шумного города.<br />\nИсключительная комфортабельность этой модели сочетается с утонченным дизайном. Велосипедистки оценят удобство широкого подпружиненного кресла, широкого руля (требуется минимум усилий для управления велосипедом даже на холмистых дорогах) и 7-скоростной трансмиссии. Оригинальной деталью Hollywood является подстаканник, расположенный возле рулевой трубы.\n<ul>\n	<li>\n		Прочная алюминиевая рама\n	</li>\n	<li>\n		7-скоростная трансмиссия японской компании Shimano\n	</li>\n	<li>\n		Регулируемый по углу наклона руль\n	</li>\n	<li>\n		Кожух цепи\n	</li>\n	<li>\n		Полнопофильные крылья\n	</li>\n	<li>\n		Подножка\n	</li>\n</ul>\n<br />\nКатегории:&nbsp;<a href=\"https://www.birota.ru/shop/velosipedy/kruizery/\">Круизеры</a><br />\n<strong>Комплектация Schwinn Hollywood 2015</strong><br />\n<strong>Рама и велосипед</strong>\n\n<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"width:851px;\" width=\"851\">\n	<tbody>\n		<tr>\n			<td style=\"width:287px;\">\n				Рама:\n			</td>\n			<td>\n				Алюминиевая Schwinn Cruiser Women-Specific 26\"\n			</td>\n		</tr>\n		<tr>\n			<td style=\"width:287px;\">\n				Заявленный вес:\n			</td>\n			<td>\n				17 кг\n			</td>\n		</tr>\n		<tr>\n			<td style=\"width:287px;\">\n				Количество скоростей:\n			</td>\n			<td>\n				7\n			</td>\n		</tr>\n		<tr>\n			<td style=\"width:287px;\">\n				Вилка:\n			</td>\n			<td>\n				Жесткая стальная Schwinn Rigid 1 1/8\"\n			</td>\n		</tr>\n		<tr>\n			<td style=\"width:287px;\">\n				Женский или мужской:\n			</td>\n			<td>\n				женский\n			</td>\n		</tr>\n		<tr>\n			<td style=\"width:287px;\">\n				Диаметр колеса:\n			</td>\n			<td>\n				26\n			</td>\n		</tr>\n	</tbody>\n</table>\n<strong>Трансмиссия</strong>\n\n<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"width:851px;\" width=\"851\">\n	<tbody>\n		<tr>\n			<td style=\"width:287px;\">\n				Тип трансмиссии:\n			</td>\n			<td>\n				звезды и переключатели\n			</td>\n		</tr>\n		<tr>\n			<td style=\"width:287px;\">\n				Переключатели на руле:\n			</td>\n			<td>\n				SRAM MRX Grip Shift\n			</td>\n		</tr>\n		<tr>\n			<td style=\"width:287px;\">\n				Задний переключатель:\n			</td>\n			<td>\n				Shimano Tourney, 7 скоростей\n			</td>\n		</tr>\n		<tr>\n			<td style=\"width:287px;\">\n				Кассета/трещотка:\n			</td>\n			<td>\n				Shimano Tourney, 14-34 зубцов\n			</td>\n		</tr>\n		<tr>\n			<td style=\"width:287px;\">\n				Цепь:\n			</td>\n			<td>\n				KMC Z51\n			</td>\n		</tr>\n		<tr>\n			<td style=\"width:287px;\">\n				Тип подвески:\n			</td>\n			<td>\n				Без амортизаторов\n			</td>\n		</tr>\n	</tbody>\n</table>\n<strong>Колеса</strong>\n\n<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"width:851px;\" width=\"851\">\n	<tbody>\n		<tr>\n			<td style=\"width:287px;\">\n				Обода:\n			</td>\n			<td>\n				Алюминиевые\n			</td>\n		</tr>\n		<tr>\n			<td style=\"width:287px;\">\n				Покрышки:\n			</td>\n			<td>\n				Schwinn Cruiser 26 x 2.125\"\n			</td>\n		</tr>\n	</tbody>\n</table>\n<strong>Тормозная система</strong>\n\n<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"width:851px;\" width=\"851\">\n	<tbody>\n		<tr>\n			<td style=\"width:287px;\">\n				Тип тормоза:\n			</td>\n			<td>\n				ободной тормоз\n			</td>\n		</tr>\n		<tr>\n			<td style=\"width:287px;\">\n				Активация тормоза:\n			</td>\n			<td>\n				ручной тормоз\n			</td>\n		</tr>\n	</tbody>\n</table>\n<strong>Управление</strong>\n\n<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"width:851px;\" width=\"851\">\n	<tbody>\n		<tr>\n			<td style=\"width:287px;\">\n				Руль:\n			</td>\n			<td>\n				Стальной Cruiser 25.4\n			</td>\n		</tr>\n		<tr>\n			<td style=\"width:287px;\">\n				Вынос:\n			</td>\n			<td>\n				Алюминиевый Quill, 25.4\n			</td>\n		</tr>\n		<tr>\n			<td style=\"width:287px;\">\n				Педали:\n			</td>\n			<td>\n				Schwinn Bow Tie, с катафотами\n			</td>\n		</tr>\n	</tbody>\n</table>\n<strong>О компании Schwinn</strong><br />\nИстория компании Schwinn началась в конце позапрошлого столетия. Можно утверждать, что самый старый в мире велобренд является настоящим ровесником велосипеда, а его инженеры во многом ответственны за облик этого двухколесного транспорта сегодня. Именно компания Schwinn представила миру первые в мире круизеры, детская серия Schwinn Sting Ray дала рождение нынешним экстремальным BMX, а городские байки Schwinn после переделки энтузиастами стали первыми в мире горными велосипедами.&nbsp;<br />\n<br />\nSchwinn сегодня – это настоящая велоклассика. Несмотря на почтенный возраст и культовый статус, компания не изменяет своему главному вековому принципу - создавать доступные, простые и надежные велосипеды для обычных велосипедистов. В основе модельного ряда вот уже почти столетие классические круизеры и городские велосипеды для ежедневной комфортной езды. Отдельное направление – скоростные гибриды и классические горные велосипеды, требующие минимального обслуживания у веломеханика.&nbsp;<br />\n<br />\n<br />\nСайт производителя:&nbsp;<a href=\"http://www.schwinnbikes.com/\" target=\"_blank\">http://www.schwinnbikes.com/</a><br />\n<strong>Schwinn Hollywood 2015 - условия гарантии</strong><br />\nВсе велосипеды Schwinn, продаваемые в нашем интернет-магазине, покрываются официальной гарантией поставщика. Гарантийный срок на продукцию Schwinn составляет 12 месяцев с момента отметки в гарантийном талоне или даты получения заказа.<br />\n&nbsp;","30000","schwinn-hollywood-2015","Schwinn-Hollywood-2015_2018-11-30_18-54-28.jpg","CN61","-1","1","","","","","0","0","","","","0","","RUR","30000","","","","","1","","","2018-11-30 22:54:32","шт."),
("62","62","21","Scool XXlite 18 Steel","Велосипед, предназначенный для детей в возрасте от четырех до восьми лет, без переключения передач. Технические особенности: стальная рама Scool Junior XX, жесткая вилка Hi-Ten, двойные обода Alloy color, передний тормоз - ручной V-Brake, задний - ножной, полная защита цепи, крылья, подножка, звонок. Подходит для обучения и прогулочного катания в городских условиях. Диаметр колес - 18 дюймов. Вес - 11,5 кг.<br />\n<a href=\"https://www.velosklad.ru/velosipedy/bike/17157/scool-xxlite-18-steel/\"><strong>Рама</strong></a><br />\nScool Junior XX 18” steel<br />\n<a href=\"https://www.velosklad.ru/velosipedy/bike/17157/scool-xxlite-18-steel/\"><strong>Вилка</strong></a><br />\nЖесткая, Hi-Ten&nbsp;<br />\nУровень: Начальный (класс 1 из 8)<br />\n<a href=\"https://www.velosklad.ru/velosipedy/bike/17157/scool-xxlite-18-steel/\"><strong>Тормоза</strong></a><br />\nОбодной V-Brake + ножной тормоз&nbsp;<br />\nУровень: Начальный (класс 1 из 8)<br />\n<strong>Ручки тормозов</strong><br />\nKids einstellbar<br />\n<a href=\"https://www.velosklad.ru/velosipedy/bike/17157/scool-xxlite-18-steel/\"><strong>Передняя втулка</strong></a><br />\nScool steel black&nbsp;<br />\nУровень: Начальный (класс 1 из 8)<br />\n<a href=\"https://www.velosklad.ru/velosipedy/bike/17157/scool-xxlite-18-steel/\"><strong>Задняя втулка</strong></a><br />\nPower Rcktrittbremsnabe&nbsp;<br />\nУровень: Начальный (класс 1 из 8)<br />\n<a href=\"https://www.velosklad.ru/velosipedy/bike/17157/scool-xxlite-18-steel/\"><strong>Система</strong></a><br />\nShun 32T, 114 mm black&nbsp;<br />\nУровень: Начальный (класс 1 из 8)<br />\n<a href=\"https://www.velosklad.ru/velosipedy/bike/17157/scool-xxlite-18-steel/\"><strong>Каретка</strong></a><br />\nCC-886, Kugellager&nbsp;<br />\nУровень: Начальный (класс 1 из 8)<br />\n<a href=\"https://www.velosklad.ru/velosipedy/bike/17157/scool-xxlite-18-steel/\"><strong>Кассета</strong></a><br />\n16T&nbsp;<br />\nУровень: Начальный (класс 1 из 8)<br />\n<a href=\"https://www.velosklad.ru/velosipedy/bike/17157/scool-xxlite-18-steel/\"><strong>Педали</strong></a><br />\nHF-316 mit Reflektoren<br />\n<a href=\"https://www.velosklad.ru/velosipedy/bike/17157/scool-xxlite-18-steel/\"><strong>Вынос</strong></a><br />\nmit Prallschutz<br />\n<a href=\"https://www.velosklad.ru/velosipedy/bike/17157/scool-xxlite-18-steel/\"><strong>Руль</strong></a><br />\nJunior Uprise 500 mm black<br />\n<a href=\"https://www.velosklad.ru/velosipedy/bike/17157/scool-xxlite-18-steel/\"><strong>Подседельный</strong> <strong>штырь</strong></a><br />\nSteel, black<br />\n<a href=\"https://www.velosklad.ru/velosipedy/bike/17157/scool-xxlite-18-steel/\"><strong>Обода</strong></a><br />\nAlloy color<br />\n<a href=\"https://www.velosklad.ru/velosipedy/bike/17157/scool-xxlite-18-steel/\"><strong>Покрышки</strong></a><br />\nScool Kids MTB 18x2,125”<br />\n<strong>Цвета выпускаемые</strong><br />\nбелый, зеленый, черный<br />\n<strong>Размеры выпускаемые</strong><br />\nОдин размер под рост от 110 см<br />\n<strong>Разработка</strong><br />\nГермания<br />\n<strong>Производство</strong><br />\nТайвань<br />\n<strong>Максимальный вес велосипедиста</strong><br />\n50 кг.<br />\n&nbsp;<br />\n&nbsp;","10800","scool-xxlite-18-steel","Scool-XXlite-18-Steel_2018-11-30_18-55-52.jpg","CN62","-1","1","","","","12000","0","0","","","","0","","RUR","10800","","","","","1","","","2018-11-30 22:55:56","шт."),
("60","60","21","Giant XtC SL Jr 24 2018","Подростковый горный велосипед Giant XtC SL Jr 24 – это не только яркий стильный дизайн, но и высокий уровень надежности. На нем удобно кататься и в черте города, и по полному бездорожью. Алюминиевая рама имеет особую конструкцию, улучшающую удобство и маневренность байка. Дисковые гидравлические тормоза отвечают за безопасность юного райдера, а амортизационная вилка – за плавное передвижение в условиях агрессивного рельефа.<br />\nТехнические характеристики Giant XtC SL Jr 24 (2018)\n<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"width:1197px;\" width=\"1196\">\n	<tbody>\n		<tr>\n			<td style=\"width:479px;\">\n				пол\n			</td>\n			<td style=\"width:718px;\">\n				мальчик\n			</td>\n		</tr>\n		<tr>\n			<td style=\"width:479px;\">\n				тип тормозов\n			</td>\n			<td style=\"width:718px;\">\n				дисковый гидравлический\n			</td>\n		</tr>\n		<tr>\n			<td style=\"width:479px;\">\n				диаметр колеса\n			</td>\n			<td style=\"width:718px;\">\n				24 дюйма\n			</td>\n		</tr>\n		<tr>\n			<td style=\"width:479px;\">\n				тип рамы\n			</td>\n			<td style=\"width:718px;\">\n				хардтейл\n			</td>\n		</tr>\n		<tr>\n			<td style=\"width:479px;\">\n				руль\n			</td>\n			<td style=\"width:718px;\">\n				Giant Sport Alloy, Low 31.8mm\n			</td>\n		</tr>\n		<tr>\n			<td style=\"width:479px;\">\n				материал рамы\n			</td>\n			<td style=\"width:718px;\">\n				алюминий\n			</td>\n		</tr>\n		<tr>\n			<td style=\"width:479px;\">\n				количество скоростей\n			</td>\n			<td style=\"width:718px;\">\n				24\n			</td>\n		</tr>\n		<tr>\n			<td style=\"width:479px;\">\n				вынос\n			</td>\n			<td style=\"width:718px;\">\n				Giant Sport Alloy, 15-Degree\n			</td>\n		</tr>\n		<tr>\n			<td style=\"width:479px;\">\n				передний тормоз\n			</td>\n			<td style=\"width:718px;\">\n				Tektro HDM290, 140mm Rotor\n			</td>\n		</tr>\n		<tr>\n			<td style=\"width:479px;\">\n				задний тормоз\n			</td>\n			<td style=\"width:718px;\">\n				Tektro HDM290, 140mm Rotor\n			</td>\n		</tr>\n		<tr>\n			<td style=\"width:479px;\">\n				цепь\n			</td>\n			<td style=\"width:718px;\">\n				KMC Z72NP\n			</td>\n		</tr>\n		<tr>\n			<td style=\"width:479px;\">\n				система\n			</td>\n			<td style=\"width:718px;\">\n				ProWheel Burner-301 42-32-22 with Chain Guard, 152mm\n			</td>\n		</tr>\n		<tr>\n			<td style=\"width:479px;\">\n				каретка\n			</td>\n			<td style=\"width:718px;\">\n				Semi-Cartridge\n			</td>\n		</tr>\n		<tr>\n			<td style=\"width:479px;\">\n				педали\n			</td>\n			<td style=\"width:718px;\">\n				One-Piece Black PP, 9-16\n			</td>\n		</tr>\n		<tr>\n			<td style=\"width:479px;\">\n				ободья\n			</td>\n			<td style=\"width:718px;\">\n				Giant Kids 24, 6061 Aluminum, Double Wall\n			</td>\n		</tr>\n		<tr>\n			<td style=\"width:479px;\">\n				передняя втулка\n			</td>\n			<td style=\"width:718px;\">\n				Joytech 041DSE, Alloy Disc hub, Double-Sealed, Loose Ball Bearing, 32H\n			</td>\n		</tr>\n		<tr>\n			<td style=\"width:479px;\">\n				задняя втулка\n			</td>\n			<td style=\"width:718px;\">\n				Joytech 142DSE, Alloy Disc hub, Double-Sealed, Loose Ball Bearing, 32H\n			</td>\n		</tr>\n		<tr>\n			<td style=\"width:479px;\">\n				передняя покрышка\n			</td>\n			<td style=\"width:718px;\">\n				Giant Junior Lite Sport, C-1866 24x1.95, 60TPI\n			</td>\n		</tr>\n		<tr>\n			<td style=\"width:479px;\">\n				задняя покрышка\n			</td>\n			<td style=\"width:718px;\">\n				Giant Junior Lite Sport, C-1866 24x1.95, 60TPI\n			</td>\n		</tr>\n		<tr>\n			<td style=\"width:479px;\">\n				седло\n			</td>\n			<td style=\"width:718px;\">\n				Giant Grow Technology Jr. Sports\n			</td>\n		</tr>\n		<tr>\n			<td style=\"width:479px;\">\n				подседельный штырь\n			</td>\n			<td style=\"width:718px;\">\n				Alloy Single-Bolt, 30.9x300mm\n			</td>\n		</tr>\n		<tr>\n			<td style=\"width:479px;\">\n				кассета\n			</td>\n			<td style=\"width:718px;\">\n				Shimano HG31 11-34, 8-speed\n			</td>\n		</tr>\n		<tr>\n			<td style=\"width:479px;\">\n				передний переключатель\n			</td>\n			<td style=\"width:718px;\">\n				Shimano M190\n			</td>\n		</tr>\n		<tr>\n			<td style=\"width:479px;\">\n				задний переключатель\n			</td>\n			<td style=\"width:718px;\">\n				Shimano Acera\n			</td>\n		</tr>\n		<tr>\n			<td style=\"width:479px;\">\n				манетки\n			</td>\n			<td style=\"width:718px;\">\n				Shimano Altus\n			</td>\n		</tr>\n		<tr>\n			<td style=\"width:479px;\">\n				рама\n			</td>\n			<td style=\"width:718px;\">\n				ALUXX-Grade Aluminum\n			</td>\n		</tr>\n		<tr>\n			<td style=\"width:479px;\">\n				вилка\n			</td>\n			<td style=\"width:718px;\">\n				SR Suntour XCR LO 24 Air, 65mm Travel, Progressive Air system\n			</td>\n		</tr>\n	</tbody>\n</table>","50000","giant-xtc-sl-jr-24-2018","Giant-XtC-SL-Jr-24-2018_2018-11-30_18-53-43.jpg","CN60","-1","1","","","","","0","0","","","","0","","RUR","50000","","","","","1","","","2018-11-30 22:53:47","шт."),
("59","59","21","CANYON Spectral CF 9.0 EX Stealth","<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"width:851px;\" width=\"851\">\n	<tbody>\n		<tr>\n			<td style=\"width:287px;\">\n				Рама:\n			</td>\n			<td>\n				CANYON Spectral Carbon\n			</td>\n		</tr>\n		<tr>\n			<td style=\"width:287px;\">\n				Вилка:\n			</td>\n			<td>\n				RockShox Pike RCT3, ход 150 мм\n			</td>\n		</tr>\n		<tr>\n			<td style=\"width:287px;\">\n				Задний амортизатор:\n			</td>\n			<td>\n				RockShox Monarch RT3, ход 140 мм\n			</td>\n		</tr>\n		<tr>\n			<td style=\"width:287px;\">\n				Рулевая колонка:\n			</td>\n			<td>\n				Cane Creek 40\n			</td>\n		</tr>\n		<tr>\n			<td style=\"width:287px;\">\n				Женский или мужской:\n			</td>\n			<td>\n				мужской\n			</td>\n		</tr>\n		<tr>\n			<td style=\"width:287px;\">\n				Диаметр колеса:\n			</td>\n			<td>\n				27.5\"\n			</td>\n		</tr>\n	</tbody>\n</table>\n<strong>Трансмиссия</strong>\n\n<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"width:851px;\" width=\"851\">\n	<tbody>\n		<tr>\n			<td style=\"width:287px;\">\n				Тип трансмиссии:\n			</td>\n			<td>\n				звезды и переключатели\n			</td>\n		</tr>\n		<tr>\n			<td style=\"width:287px;\">\n				Переключатели на руле:\n			</td>\n			<td>\n				SRAM X01 Eagle Trigger, 12 скоростей\n			</td>\n		</tr>\n		<tr>\n			<td style=\"width:287px;\">\n				Задний переключатель:\n			</td>\n			<td>\n				SRAM X01 Eagle, 12 скоростей\n			</td>\n		</tr>\n		<tr>\n			<td style=\"width:287px;\">\n				Система:\n			</td>\n			<td>\n				SRAM X1 Eagle carbon, звезда 34 зубца\n			</td>\n		</tr>\n		<tr>\n			<td style=\"width:287px;\">\n				Кассета/трещотка:\n			</td>\n			<td>\n				SRAM XG-1295 Eagle, диапазон 10-50 зубцов\n			</td>\n		</tr>\n		<tr>\n			<td style=\"width:287px;\">\n				Цепь:\n			</td>\n			<td>\n				SRAM X01 Eagle\n			</td>\n		</tr>\n		<tr>\n			<td style=\"width:287px;\">\n				Каретка:\n			</td>\n			<td>\n				SRAM GXP press fit\n			</td>\n		</tr>\n		<tr>\n			<td style=\"width:287px;\">\n				Тип подвески:\n			</td>\n			<td>\n				Полноподвес\n			</td>\n		</tr>\n	</tbody>\n</table>\n<strong>Колеса</strong>\n\n<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"width:851px;\" width=\"851\">\n	<tbody>\n		<tr>\n			<td style=\"width:287px;\">\n				Обода:\n			</td>\n			<td>\n				DT Swiss XM 1501 Spline One, ширина 30 мм\n			</td>\n		</tr>\n		<tr>\n			<td style=\"width:287px;\">\n				Втулки:\n			</td>\n			<td>\n				DT Swiss XM 1501 Spline One\n			</td>\n		</tr>\n		<tr>\n			<td style=\"width:287px;\">\n				Спицы:\n			</td>\n			<td>\n				Dt Swiss, кованные, straigthpull\n			</td>\n		</tr>\n		<tr>\n			<td style=\"width:287px;\">\n				Покрышки:\n			</td>\n			<td>\n				передняя: Maxxis High Roller II 2.3\", задняя: Maxxis Minion Semi Slick 2.3\"\n			</td>\n		</tr>\n	</tbody>\n</table>\n<strong>Тормозная система</strong>\n\n<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"width:851px;\" width=\"851\">\n	<tbody>\n		<tr>\n			<td style=\"width:287px;\">\n				Тип тормоза:\n			</td>\n			<td>\n				дисковый тормоз\n			</td>\n		</tr>\n		<tr>\n			<td style=\"width:287px;\">\n				Модель тормоза:\n			</td>\n			<td>\n				SRAM Guide RSC, тормозные диски 200/180 мм\n			</td>\n		</tr>\n		<tr>\n			<td style=\"width:287px;\">\n				Тормозные ручки:\n			</td>\n			<td>\n				SRAM Guide RSC\n			</td>\n		</tr>\n		<tr>\n			<td style=\"width:287px;\">\n				Активация тормоза:\n			</td>\n			<td>\n				ручной тормоз\n			</td>\n		</tr>\n	</tbody>\n</table>\n<strong>Управление</strong>\n\n<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"width:851px;\" width=\"851\">\n	<tbody>\n		<tr>\n			<td style=\"width:287px;\">\n				Руль:\n			</td>\n			<td>\n				Renthal Fat Bar Lite, ширина 760 мм\n			</td>\n		</tr>\n		<tr>\n			<td style=\"width:287px;\">\n				Грипсы-обмотка:\n			</td>\n			<td>\n				Ergon GE10 Slim\n			</td>\n		</tr>\n		<tr>\n			<td style=\"width:287px;\">\n				Вынос:\n			</td>\n			<td>\n				Renthal Apex 35, 40 мм, угол +- 6°\n			</td>\n		</tr>\n		<tr>\n			<td style=\"width:287px;\">\n				Подседельный штырь:\n			</td>\n			<td>\n				RockShox Reverb Stealth, регулируемый, ход 125 мм\n			</td>\n		</tr>\n		<tr>\n			<td style=\"width:287px;\">\n				Седло:\n			</td>\n			<td>\n				SDG Circuit MTN, хром-молибденовые рамки, микрофибра\n			</td>\n		</tr>\n	</tbody>\n</table>","339900","canyon-spectral-cf-9-0-ex-stealth","CANYON-Spectral-CF-90-EX-Stealth_2018-11-30_18-51-31.jpg","CN59","-1","1","","","","350000","0","0","","","","0","","RUR","339900","","","","","1","","","2018-11-30 22:52:05","шт."),
("57","57","22","Трос-замок GK101.708","Замок с пятизначным шифром GK101.708 обеспечит надежную защиту велосипеда на парковке или во время кратковременных стоянок у магазина. Основным достоинством модели является толстый трос диаметром 15 мм и длиной 930 мм. Он не царапает раму и другие элементы байка, поскольку находится в ПВХ-рубашке.<br />\n<strong>Марка</strong><br />\nStels<br />\n<strong>Модель</strong><br />\nGK101.708<br />\n<strong>Материал</strong><br />\nсталь/ПВХ<br />\n<strong>Особенности</strong><br />\nс шифром<br />\n<strong>Длина</strong><br />\n15x930мм<br />\n<strong>Цвета (выпускаемые)</strong><br />\nчерный<br />\n&nbsp;<br />\n&nbsp;","490","tros-zamok-gk101-708","tros-zam-GK101708_2018-11-30_18-49-39.jpg","CN57","-1","1","","","","","0","0","","","","0","","RUR","490","","","","","1","","","2018-11-30 22:50:00","шт."),
("58","58","21","Author Ultrasonic 26 2018","<strong>Комплектация Author Ultrasonic 26 2018</strong>&nbsp; &nbsp; &nbsp; &nbsp;<br />\n<strong>Рама и велосипед</strong>\n\n<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"width:851px;\" width=\"851\">\n	<tbody>\n		<tr>\n			<td style=\"width:287px;\">\n				Рама:\n			</td>\n			<td>\n				алюминий, тройное баттирование, гидроформирование 6061 26\"\n			</td>\n		</tr>\n		<tr>\n			<td style=\"width:287px;\">\n				Количество скоростей:\n			</td>\n			<td>\n				11\n			</td>\n		</tr>\n		<tr>\n			<td style=\"width:287px;\">\n				Вилка:\n			</td>\n			<td>\n				алюминиевая 6061 26\"\n			</td>\n		</tr>\n		<tr>\n			<td style=\"width:287px;\">\n				Рулевая колонка:\n			</td>\n			<td>\n				AUTHOR интегрированная, коническая 1.5\"\n			</td>\n		</tr>\n		<tr>\n			<td style=\"width:287px;\">\n				Год:\n			</td>\n			<td>\n				2018\n			</td>\n		</tr>\n		<tr>\n			<td style=\"width:287px;\">\n				Женский или мужской:\n			</td>\n			<td>\n				мужской\n			</td>\n		</tr>\n		<tr>\n			<td style=\"width:287px;\">\n				Диаметр колеса:\n			</td>\n			<td>\n				26\n			</td>\n		</tr>\n	</tbody>\n</table>\n<strong>Трансмиссия</strong>\n\n<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"width:851px;\" width=\"851\">\n	<tbody>\n		<tr>\n			<td style=\"width:287px;\">\n				Тип трансмиссии:\n			</td>\n			<td>\n				звезды и переключатели\n			</td>\n		</tr>\n		<tr>\n			<td style=\"width:287px;\">\n				Переключатели на руле:\n			</td>\n			<td>\n				SRAM NX-1 (11)\n			</td>\n		</tr>\n		<tr>\n			<td style=\"width:287px;\">\n				Задний переключатель:\n			</td>\n			<td>\n				SRAM NX-1\n			</td>\n		</tr>\n		<tr>\n			<td style=\"width:287px;\">\n				Система:\n			</td>\n			<td>\n				SRAM NX-1, звезда 32 зуба, шатуны 155 мм\n			</td>\n		</tr>\n		<tr>\n			<td style=\"width:287px;\">\n				Кассета/трещотка:\n			</td>\n			<td>\n				SRAM PG1130, диапазон 11-42 зубьев\n			</td>\n		</tr>\n		<tr>\n			<td style=\"width:287px;\">\n				Цепь:\n			</td>\n			<td>\n				SRAM CN-1100\n			</td>\n		</tr>\n		<tr>\n			<td style=\"width:287px;\">\n				Каретка:\n			</td>\n			<td>\n				SRAM BB\n			</td>\n		</tr>\n		<tr>\n			<td style=\"width:287px;\">\n				Тип подвески:\n			</td>\n			<td>\n				Без амортизаторов\n			</td>\n		</tr>\n	</tbody>\n</table>\n<strong>Колеса</strong>\n\n<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"width:851px;\" width=\"851\">\n	<tbody>\n		<tr>\n			<td style=\"width:287px;\">\n				Обода:\n			</td>\n			<td>\n				AUTHOR Radon 26, 32 отверстия\n			</td>\n		</tr>\n		<tr>\n			<td style=\"width:287px;\">\n				Втулки:\n			</td>\n			<td>\n				AUTHOR Xenon, 32 отверстия\n			</td>\n		</tr>\n		<tr>\n			<td style=\"width:287px;\">\n				Спицы:\n			</td>\n			<td>\n				нержавеющая сталь, черные, 2.0 мм\n			</td>\n		</tr>\n		<tr>\n			<td style=\"width:287px;\">\n				Покрышки:\n			</td>\n			<td>\n				VITTORIA Barzo kevlar 26\" x 2.10\"\n			</td>\n		</tr>\n	</tbody>\n</table>\n<strong>Тормозная система</strong>\n\n<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"width:851px;\" width=\"851\">\n	<tbody>\n		<tr>\n			<td style=\"width:287px;\">\n				Тип тормоза:\n			</td>\n			<td>\n				дисковый тормоз\n			</td>\n		</tr>\n		<tr>\n			<td style=\"width:287px;\">\n				Модель тормоза:\n			</td>\n			<td>\n				дисковые гидравлические TEKTRO Auriga, 160 мм\n			</td>\n		</tr>\n		<tr>\n			<td style=\"width:287px;\">\n				Тормозные ручки:\n			</td>\n			<td>\n				TEKTRO Auriga WS\n			</td>\n		</tr>\n		<tr>\n			<td style=\"width:287px;\">\n				Активация тормоза:\n			</td>\n			<td>\n				ручной тормоз\n			</td>\n		</tr>\n	</tbody>\n</table>\n<strong>Управление</strong>\n\n<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"width:851px;\" width=\"851\">\n	<tbody>\n		<tr>\n			<td style=\"width:287px;\">\n				Руль:\n			</td>\n			<td>\n				AUTHOR, подъем 0 mm, ширина 600 mm\n			</td>\n		</tr>\n		<tr>\n			<td style=\"width:287px;\">\n				Грипсы-обмотка:\n			</td>\n			<td>\n				AUTHOR, пена высокой плотности\n			</td>\n		</tr>\n		<tr>\n			<td style=\"width:287px;\">\n				Вынос:\n			</td>\n			<td>\n				алюминий, AUTHOR\n			</td>\n		</tr>\n		<tr>\n			<td style=\"width:287px;\">\n				Подседельный штырь:\n			</td>\n			<td>\n				алюминий, AUTHOR (диаметр 31.6)\n			</td>\n		</tr>\n		<tr>\n			<td style=\"width:287px;\">\n				Седло:\n			</td>\n			<td>\n				AUTHOR Champion CR\n			</td>\n		</tr>\n		<tr>\n			<td style=\"width:287px;\">\n				Подседельный хомут:\n			</td>\n			<td>\n				AUTHOR, диаметр зажима 34.9 мм\n			</td>\n		</tr>\n		<tr>\n			<td style=\"width:287px;\">\n				Педали:\n			</td>\n			<td>\n				алюминий\n			</td>\n		</tr>\n	</tbody>\n</table>\n<strong>О компании Author</strong><br />\nAuthor, пожалуй, самый известный производитель велосипедов из восточной Европы. Проект, который начался 20 лет назад как частная торговая марка для сети спортивных магазинов, неожиданно встретил энтузиазм покупателей и сегодня давно стал самостоятельным и сильным брендом с широким модельным рядом и своими производственными мощностями. Основной сегмент и специализация компании, это велосипеды среднего уровня всех типов.&nbsp;<br />\n<br />\nКак хороший производитель для массового рынка, компания использует современные системы контроля качества и, по опыту наших продаж следствием этого явился крайне низкий процент поломок и брака. Hi-end линейка карбоновых спортивных велосипедов разрабатывается в Чехии, а производится в Тайване на базе рам фирмы Carbotec, крупнейшего производителя рам для таких брендов как Storck, Wilier, Pinarello.&nbsp;<br />\n<br />\n<br />\nСайт производителя:&nbsp;<a href=\"http://www.author.eu/\" target=\"_blank\">http://www.author.eu/</a><br />\n<strong>Author Ultrasonic 26 2018 - условия гарантии</strong><br />\nВсе велосипеды Author, продаваемые в нашем интернет-магазине, покрываются официальной гарантией поставщика. По Петербургу велосипед доставляется в полностью собранном и настроенным веломехаником виде. При доставке в другие регионы, велосипед проверяется на комплектность, наличие брака и упаковывается назад заводскую коробку. Гарантийный срок на продукцию Author составляет 12 месяцев с момента отметки в гарантийном талоне или даты получения заказа.&nbsp;<br />\n<br />\nПомимо полностью собранного и настроенного велосипеда, к велосипеду идет сопроводительный комплект документов, удостоверяющих дату продажи и начало гарантийного срока обслуживания в сервисной книжке. Официальный сервисный центр компании Author расположен на пр. Шаумяна, дом 2.&nbsp;<br />\n<br />\nТаким образом, покупка данного велосипеда через интернет ничем не отличается от покупки в магазине, кроме двух немаловажных фактов:&nbsp;\n<ul>\n	<li>\n		велосипед доставляется к вашему дому\n	</li>\n	<li>\n		это будет абсолютно новый велосипед собранный под ваш заказ, миновавший витрину и тестовые поездки других покупателей\n	</li>\n</ul>","53000","author-ultrasonic-26-2018","Author-Ultrasonic-26-2018_2018-11-30_18-51-00.jpg","CN58","-1","1","","","","","0","0","","","","0","","RUR","53000","","","","","1","","","2018-11-30 22:51:08","шт."),
("56","56","0","Очиститель  универсальный DirtWash Bike Cleaner","Weldtite Dirtwash Bike Cleaner - универсальный очиститель велосипеда. Средство эффективно удаляет различные виды загрязнений. Совершенно безопасно для лакокрасочного покрытия. Для удобного нанесения средства флакон оснащён распылителем. Объём составляет 1 литр.<br />\n<strong>Марка</strong><br />\nWeldtite<br />\n<strong>Модель</strong><br />\nDirtWash Bike Cleaner<br />\n<strong>Объем</strong><br />\n1л<br />\n&nbsp;","920","ochistitel-universalnyy-dirtwash-bike-cleaner","ochistitel-velosipeda-universalnyy-DirtWash-Bike-Cleaner_2018-11-30_18-47-08.jpg","CN56","-1","1","","","","","0","0","","","","0","","RUR","920","","","","","1","","","2018-11-30 22:47:14","шт."),
("55","55","22","Велокомпьютер Stels BRI-9W","Компактный беспроводной велокомпьютер Stels BRI-9W поможет вам собрать подробную статистику ваших заездов и отследить результаты тренировок. Водонепроницаемый пластиковый корпус, легкочитаемый дисплей и всего лишь одна кнопка управления позволяют удобно использовать его в любых погодных условиях. Имеет 9 функций: часы 12/24, скорость текущая/средняя/максимальная, время в пути, текущее/общее расстояние, сканирование данных, счетчик калорий. В комплект входит универсальный крепеж и магнитный датчик. Цвет: черный<br />\n&nbsp;<br />\n<strong>Марка</strong><br />\nStels<br />\n<strong>Модель</strong><br />\nBRI-9W<br />\n<strong>Материал</strong><br />\nпластик<br />\n<strong>Функции</strong><br />\n9 функций<br />\n<strong>Особенности</strong><br />\nбеспроводной<br />\n<strong>Цвета (выпускаемые)</strong><br />\nчерный<br />\n<strong>Цвет в наличии:</strong><br />\nсер<br />\n&nbsp;","1600","velokompyuter-stels-bri-9w","velokompyuter-Stels-BRI-9W_2018-11-30_18-44-57.jpg","CN55","-1","1","","","","2000","0","0","","","","0","","RUR","1600","","","","","1","","","2018-11-30 22:46:24","шт."),
("54","54","22","ZF-037 с манометром","Напольный насос ручной ZF-037 стационарный. С ним вы сможете быстро, точно и с удобством накачать шины любого типа, шланг с автовентилем и переходником на велосипедный вентиль. Рабочее давление - 11 бар. Насос имеет корпус из алюминия, прочный и устойчивый. Оснащен манометром для уточнения давления. Имеет привлекательный оригинальный внешний вид. Качественно изготовлен.<br />\n<strong>Модель</strong><br />\nZF-037<br />\n<strong>Особенности</strong><br />\nшланг с автовентилем и переходником на велосипедный вентиль<br />\n<strong>Размеры (выпускаемые)</strong><br />\nдиаметр 38мм и высота 530 мм<br />\n<strong>Производство</strong><br />\nТайвань<br />\n<strong>Разработка</strong><br />\nТайвань<br />\n<strong>Цвета (выпускаемые)</strong><br />\nчерно-оранжевый<br />\n&nbsp;<br />\n&nbsp;","950","zf-037-s-manometrom","ZF-037-s-manometrom,-napolnyy_2018-11-30_18-43-22.jpg","CN54","51","1","","","","","0","0","","","","0","","RUR","950","","","","","1","","","2018-11-30 22:43:39","шт."),
("53","53","24","Темобельё FOX ATTACK BASE FIRE","Термобельё разработанное для активности в холодные дни.<br />\n• Специальная кольцевая вязка материала TermoLite со специальными зонами, позволяют белью отлично отводить влагу, дышать и греть<br />\n• Минимальное количество швов, для большего комфорта в движении<br />\n• Компрессионные зоны для лучшей посадки\n<table cellpadding=\"0\" cellspacing=\"0\" width=\"100%\">\n	<tbody>\n		<tr>\n			<td width=\"50%\">\n				Бренд:\n			</td>\n			<td>\n				<a href=\"javascript:void(0)\" onclick=\"showBrand();\">FOX</a>\n			</td>\n		</tr>\n		<tr>\n			<td>\n				Год:\n			</td>\n			<td>\n				2018/2019\n			</td>\n		</tr>\n		<tr>\n			<td>\n				Пол:\n			</td>\n			<td>\n				Для мужчин\n			</td>\n		</tr>\n		<tr>\n			<td>\n				Возраст:\n			</td>\n			<td>\n				Для взрослых\n			</td>\n		</tr>\n	</tbody>\n</table>","4600","temobelyo-fox-attack-base-fire","1_2018-11-28_19-23-04.jpg","CN53","10","1","","","","5456","0","0","","","","0","","RUR","4600","","","","","1","","","2018-11-28 23:23:21","шт."),
("66","66","25","Набор инструментов Park Tool MK-222","Набор инструментов для профессиональной мастерской Park Tool Master Tool Kit MK-222, 222 предмета, весь инструмент для того что открыть мастерскую.<br />\n&nbsp;","180000","nabor-instrumentov-park-tool-mk-222","nabor-instrumentov-Park-Tool-MK-222_2018-11-30_18-59-11.jpg","CN66","-1","1","","","","218000","0","0","","","","0","","RUR","180000","","","","","1","","","2018-11-30 22:59:15","шт."),
("67","67","0","Набор инструментов Park Tool TWS-2C","Набор инструментов, складной, торкс, T7/9/10/15/20/25/27/30/40. Вес 168 грамм.","1300","nabor-instrumentov-park-tool-tws-2c","nabor-instrumentov-Park-Tool-TWS-2C_2018-11-30_18-59-35.jpg","CN67","-1","1","","","","","0","0","","","","0","","RUR","1300","","","","","1","","","2018-11-30 22:59:50","шт."),
("68","68","0","Зимние велотуфли Shimano MW 7","<p>\n	<strong>Зимние мембранные велотуфли Shimano MW7</strong>\n</p>\n\n<p>\n	<strong>Характеристики:</strong>\n</p>\n\n<p>\n	- Утепленные и водонепроницаемые\n</p>\n\n<p>\n	- Утепляющая подкладка из мембраны&nbsp;<strong>GORE-TEX®</strong>Insulated Comfort\n</p>\n\n<p>\n	- Защита шнуровки\n</p>\n\n<p>\n	- Стелька с подкладкой из флиса для дополнительного тепла\n</p>\n\n<p>\n	- Светоотражатели со всех сторон\n</p>\n\n<p>\n	- Резиновая подошва для улученого сцепления на мкором и скользком покрытии\n</p>\n\n<p>\n	<strong>Возможно использование и без применения контактных педалей.</strong>\n</p>","7000","zimnie-velotufli-shimano-mw-7","zimnie-velotufli-Shimano-MW-7_2018-11-30_19-00-31.jpg","CN68","-1","1","","","","","0","0","","","","0","","RUR","7000","","","","","1","","","2018-11-30 23:00:50","шт."),
("69","69","24","Комбенизон Verducci Racing","<p>\n	Комбенизон&nbsp;<strong>Verducci Racing</strong>\n</p>\n\n<p>\n	<strong>Назначение:</strong>&nbsp;роллер спорт, велоспорт\n</p>\n\n<p>\n	Характеристики:\n</p>\n\n<p>\n	- анатомический покрой\n</p>\n\n<p>\n	- высокая эластичность ткани\n</p>\n\n<p>\n	- плоские швы\n</p>\n\n<p>\n	- 3/4 скрытый замок-молния\n</p>\n\n<p>\n	- без памперса\n</p>\n\n<p>\n	<strong>Половая принадлежность:</strong>&nbsp;унисекс\n</p>\n\n<p>\n	<strong>Материал:</strong><b>&nbsp;</b>100% Lycra (DuPont®)\n</p>","3500","kombenizon-verducci-racing","kombinezon-Verducci-Racing_2018-11-30_19-01-07.jpg","CN69","-1","1","","","","","0","0","","","","0","","RUR","3500","","","","","1","","","2018-11-30 23:01:29","шт."),
("70","70","0","Летние велоштаны RockBros","<strong>Летние велоштаны</strong>&nbsp;<strong>RockBros</strong><br />\n<strong>Назначение:</strong>&nbsp;велоспорт, фитнес<br />\n<strong>Гендерная принадлежность:</strong>&nbsp;унисекс<br />\n<strong>Характеристики:</strong><br />\n<strong>- эластичный материал</strong><br />\n- анатомический покрой<br />\n- плоские швы<br />\n- расшито колено, низ заужен<br />\n- широкий пояс со шнуровкой<br />\n- карманы с замком-молнией<br />\n- на лодыжке молнии для стягивания штанин во избежании попадания в цепь<br />\n- вшиты светоотражающие элементы<br />\n- по бокам вшиты вентиляционные каналы на молнии для дополнительной вентиляции в случае необходимости<br />\n-&nbsp;<strong>rip-stop материал спереди (защита от затяжек)</strong>\n\n<ul>\n	<li>\n		<strong>Материал:</strong>&nbsp;Polyester 100%; Спереди ткань с rip-stop функциональностью.\n	</li>\n	<li>\n		<strong>Данные велоштаны будут идеальны при комбинированном использовании с&nbsp;&nbsp;<a href=\"http://www.veloodejda.ru/shop/%D0%92%D0%B5%D0%BB%D0%BE%D0%BE%D0%B4%D0%B5%D0%B6%D0%B4%D0%B0/%D0%92%D0%B5%D0%BB%D0%BE%D1%82%D1%80%D1%83%D1%81%D1%8B-%D0%B1%D0%B5%D0%B7-%D0%BB%D1%8F%D0%BC%D0%BE%D0%BA\">велотрусами</a>.</strong>\n	</li>\n	<li>\n		<strong>Рекомендуемая температура для применения:</strong>&nbsp;от +7°С до +30°С\n	</li>\n</ul>","2000","letnie-veloshtany-rockbros","letnie-veloshtany-RockBros_2018-11-30_19-02-10.jpg","CN70","-1","1","","","","2100","0","0","","","","0","","RUR","2000","","","","","1","","","2018-11-30 23:02:12","шт.");


INSERT INTO `mg_product_rating` VALUES
("28","16","5","1");









INSERT INTO `mg_slider-action` VALUES
("1","img","Велоаксессуары","http://velovel.ru/veloaksessuary","<img src=\'http://velovel.ru/uploads/logo/ak.jpg\' alt=\'Велоаксессуары\' title=\'Велоаксессуары\'>","1","1"),
("2","img","Велосипеды","http://velovel.ru/velosipedy","<img src=\'http://velovel.ru/uploads/logo/detvel.jpg\' alt=\'Велосипеды\' title=\'Велосипеды\'>","2","1"),
("4","img","Велоодежда","http://velovel.ru/veloodejda","<img src=\'http://velovel.ru/uploads/logo/od.jpg\' alt=\'Велоодежда\' title=\'Велоодежда\'>","4","0");





INSERT INTO `mg_user` VALUES
("1","admin@admin.ru","4d9c45c858ceb5a1991c686308af9485","1","Администратор","","","","","","","","","","","2018-11-28 21:30:29","2015-11-24 14:03:00","0","","1","","","","","","","","","",""),
("12","user4@moguta.ru","1851aa8a168ddf208b117a509a8a9054","2","Иван Иванов","","","","","","","","","","+7 (777) 777-77-77","2018-11-28 21:30:29","2015-12-03 13:14:10","0","","0","","","","","","","","","",""),
("11","user3@moguta.ru","019d0fecaa6c5b92562ece6fb8d95487","2","Покупатель","","","","","","","","","","","2018-11-28 21:30:29","2015-12-03 13:13:11","0","","0","","","","","","","","","",""),
("10","user2@moguta.ru","2dc64589a135f778aa69c4f73918df8d","2","Покупатель","","","","","","","","","","+7 (555) 555-55-55","2018-11-28 21:30:29","2015-12-03 13:11:21","0","","0","123123","","ООО Юр лицо","","","","","","",""),
("9","user@moguta.ru","bd3a9454f73a6a6d017852df2a60b968","2","Пользователь","","","","","","","","","","+7 (988) 888-88-88","2018-11-28 21:30:29","2015-12-03 13:08:57","0","","0","","","","","","","","","","127.0.0.1"),
("13","admin@mail.ru","$1$38/.OX/.$9kFCCGGHu4bxl8NVtnQ6A1","1","Администратор","","","","","","","","","","","2018-12-05 20:25:58","2018-11-28 21:30:29","0","","1","","","","","","","","","","");

INSERT INTO `mg_user_group` VALUES
("-1","0","Гость (Не авторизован)","0","0","0","0","0","0","0","0","0"),
("1","0","Администратор","1","2","2","2","2","2","2","2","1"),
("2","0","Пользователь","0","0","0","0","0","0","0","0","0"),
("3","0","Менеджер","1","2","0","1","2","0","2","0","0"),
("4","0","Модератор","1","1","2","0","0","0","2","0","0");


